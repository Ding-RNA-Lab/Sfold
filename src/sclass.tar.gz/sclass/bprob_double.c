/*
 * Using bprob.out from Sfold, this program calculates the
 * Boltzmann probability of a structure with known minimum
 * free energy
 */

#include <stdio.h>
#include <stdlib.h>

/* 2006/11/15: the ldouble library produces incorrect results
 * under solaris sparc. This has to do with the big endian
 * floating point representation in sparc. Instead of messing
 * with the ldouble library config, we can simply use the
 * libsunmath under solaris to do the long double calculations.
 * It appears that for Sun Studio 10 and later, these calls
 * are included into the general libm library, so it does not
 * even require the sunmath on those platforms. bioquad
 * currently has Sun Studio 8.
 */
#include <math.h>
#define MAXBUF	256
//#define DEBUG

double read_ld(FILE *fp);
void usage(char *pn);

int main(int argc, char *argv[]) {
  double u0, u1n, scale, prob;
  double fe;
  int n;
  FILE *fp;
  char buf[MAXBUF];

  if (argc != 3)
    usage(argv[0]);

//  if ((fe=atof(argv[2])) == 0.0) {
  if ((fe=atof(argv[2])) == 0.0 && argv[2][0] != '0') {
    fprintf(stderr, " Error: invalid free energy\n");
    return -1;
  }

  if ((fp=fopen(argv[1], "r")) == NULL) {
    fprintf(stderr, " Error: unable to open file %s\n", argv[1]);
    return -1;
  }

//  fscanf(fp, "%Lg", &scale);
//  fgetc(fp);
//  fscanf(fp, "%Lg", &u1n);
//  fgetc(fp);
//  fscanf(fp, "%d", &n);
//  fgetc(fp);
//  fscanf(fp, "%Lg", &u0);
//  fgetc(fp);

  /* 2004/1/7: change the way to read in long double to make the program
     more error resistant, as the E (exponential) character might be missing
     in the input floating point number occasionally */
  scale = read_ld(fp);
  u1n = read_ld(fp);
  /* 2004/11/9: change the way to read in the sequence length n. Since
   * bprob.out is returned by the fortran main program and the way
   * fortran prints to standard output (write(0, *)) differs on
   * different platforms. Some introduces a lot of spaces before the n,
   * so we cannot just call fscanf for an integer here.
   */
  fscanf(fp, "%[^\n]", buf);
  fgetc(fp);
  sscanf(buf, "%d", &n);
  u0 = read_ld(fp);

#ifdef DEBUG
  printf("fe        = %f\n", fe);
  printf("scale     = %.20Lg\n", scale);
  printf("u1n       = %.20Lg\n", u1n);
  printf("n         = %d\n", n);
  printf("u0        = %.20Lg\n", u0);
  printf("log(u1n) = %.20Lg\n", log(u1n));
  printf("log(u0)  = %.20Lg\n", log(u0));
  printf("log(prob)= %.20Lg\n\n", (double) -scale*fe - log(u1n) - log(u0)*n);
#endif

  fclose(fp);

  prob = exp(-scale*fe - log(u1n) - log(u0)*n);
  printf("%g\n", prob);

  return 0;
}


double read_ld(FILE *fp) {
  char buf[MAXBUF];
  double e;
  int i = 0, c, got_e = 0;

  c = fgetc(fp);
  while (c != EOF && c != '\n' && i < (MAXBUF-1)) {
    if ((c == 'E' || c == 'e') && !got_e)
      got_e = 1;
    else if ((c == '+' || c == '-') && i != 0 && !got_e)
      buf[i++] = 'E';
    buf[i++] = (char) c;
    c = fgetc(fp);
  }
  buf[i++] = '\0';

  sscanf(buf, "%lg", &e);

  return e;
}


void usage(char *pn) {
  printf("Usage: %s <bprob.out from Sfold> <free energy>\n", pn);
  exit(-1);
}

/**
 * Required cleanup definition, needed to use die
 **/
void cleanup(void) {}
