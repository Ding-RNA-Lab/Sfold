#include <stdio.h>
#include "distlib.h"
#include "centroid.h"


void compute_bpcount(structure **st, int nst, int *bpc, int seqlen) {
  int i, idx, vsize;
  basepair *node;

  vsize = (seqlen-1) * seqlen / 2;

  for (i=0; i<nst; i++) {
    node = st[i]->firstbp;
    while (node != NULL) {
      idx = 0;
      twod2oned(node->i, node->j, &idx, seqlen);
      if (idx >= 1 && idx <= vsize)
        bpc[idx-1]++;
      else die(" Error: invalid index returned by twod2oned()\n");
      node = node->next;
    }
  }
}


structure *compute_centroid(int *bpc, int seqlen, int nst) {
  structure *st;
  int vsize, i, x, y;

  st = new_structure();

  vsize = (seqlen-1) * seqlen / 2;
  for (i=0; i<vsize; i++) {
//    if (overthreshold(bpc[i])) {
    if (bpc[i] > PTHRESHOLD * nst) {
      oned2twod(i+1, &x, &y, seqlen);
      add_bp_to_structure(x, y, st);

      /* here we are trying to skip to the end of a line in the upper
       * triangle. this is because we have already found a pair for
       * base, and as base triples are not allowed, we don't need to
       * check the rest of the pairing concerning this base.
       */
      if (y < seqlen) {
        twod2oned(x, seqlen, &i, seqlen);
        /* need to decrement 1 here cuz the loop counter starts at 0 */
        i--;
      }
    }
  }

  return st;
}

