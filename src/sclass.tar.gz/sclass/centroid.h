/* Threshold for including a base pair into the centroid */
#define PTHRESHOLD	0.5

#define overthreshold(x)	(x > PTHRESHOLD)


extern void compute_bpcount(structure **st, int nst, int *bpc, int seqlen);
extern structure *compute_centroid(int *bpc, int seqlen, int nst);
