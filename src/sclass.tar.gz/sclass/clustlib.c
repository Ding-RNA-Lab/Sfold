#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include "clustlib.h"

void build_vector(char *fn, float *elts, int v) {
  int started = 0, n = 0, num1, num2, i, count = 0;
  FILE *fp;
  char b[MAX_BUFFER];
  char *cp;

  if ((fp=fopen(fn, "r")) == NULL)
    die(" Error: unable to open file in build_vector().\n");

  while (fgets(b, MAX_BUFFER-1, fp) != NULL) {
    cp = strtok(b, " ");
    if (cp != NULL) {
      if (strcmp(cp, "1") == 0)
        started = 1;
      if (strstr(cp, "Length") != NULL) {
        cp = strtok(NULL, " ");
        n = atoi(cp);
        if (n == 0)
          die(" Error: unknown file format found in build_vector().\n");
        continue;
      }

      if (started && n != 0) {
        num1 = atoi(cp);
        cp = strtok(NULL, " ");
        cp = strtok(NULL, " ");
        cp = strtok(NULL, " ");
        cp = strtok(NULL, " ");
        if (cp == NULL)
          continue;
        num2 = atoi(cp);
        if (num2 > num1) {
//          if (count >= v)
//            die(" Error: size of vector not consistent.\n");
          for (i=num1; i<(num2-1); i++)
            elts[count++] = 0.0;
          elts[count++] = 1.0;
          for (i=num2; i<n; i++)
            elts[count++] = 0.0;
        } else {
          for (i=num1; i<n; i++)
            elts[count++] = 0.0;
        }
      }
    }
  }

  fclose(fp);
}


float euclidean(float *a, float *b, int n) {
  int i;
  float sum = 0.0;

  for (i=0; i<n; i++)
    sum += (float) pow((double) (a[i]-b[i]), 2.0);

  return sum;
}


int find_nsamples(char *bpfile) {
  FILE *fp;
  int ns;
  char line[MAX_BUFFER];

  if ((fp=fopen(bpfile, "r")) == NULL)
    die(" Error: Unable to open base pair file\n");

  ns = 0;
  while(fgets(line, MAX_BUFFER-1, fp) != NULL) {
    if (strstr(line, "Structure") != NULL)
      ns++;
  }

  fclose(fp);

  return ns;
}


float *getrowfromvector(float *a, int nrows, int idx) {
  int i, j, inc, count = 0;
  float *ptr;

  if (a == NULL || nrows <= 0 || idx <= 0 || idx > nrows)
    return NULL;

  ptr = (float *) malloc(sizeof(float) * (nrows-1));
  if (ptr == NULL)
    die(" Error: unable to allocate memory\n");

  inc = nrows - 1;
  i = idx - 1 - inc;
  for (j=0; j<idx-1; j++) {
    i += inc;
    inc -= 1;
    ptr[count++] = a[i-1];
//    printf("%d ", i);
  }
//  printf("; ");

  i += nrows + 1 - idx;
  for (j=0; j<nrows-idx; j++)
    ptr[count++] = a[i+j-1];
//    printf("%d ", i+j);

//  printf("\n");

  return ptr;
}


int lookup(int elt, int *array, int size) {
  int found = 0, i;

  for (i=0; i<size; i++)
    if (array[i] == elt) {
      found = 1;
      break;
    }

  return found;
}


float sum_across(float *a, int n) {
  int i;
  float sum = 0.0;

  for (i=0; i<n; i++)
    sum += a[i];

  return sum;
}


/*
 * Functions to work on the clustout data structure
 */
clustout *new_clustout(int nclust) {
  clustout *co = NULL;
  int i;

  if (nclust <= 0 || nclust > MAX_CLUSTERS)
    die(" Error: invalid number of clusters for creating clustout\n");

  co = (clustout *) malloc(sizeof(clustout));
  if (co == NULL)
    die(" Error: unable to allocate memory\n");

  co->nclust = nclust;
  co->ntotal = 0;

  co->cmembers = (clustmem *) malloc(sizeof(clustmem) * nclust);
  if (co->cmembers == NULL)
    die(" Error: unable to allocate memory\n");
  for (i=0; i<nclust; i++) {
    co->cmembers[i].csize = 0;
    co->cmembers[i].added = 0;
    co->cmembers[i].sid = NULL;
    co->cmembers[i].members = NULL;
  }

  return co;
}


void set_cluster_size(clustout *co, int cid, int size) {
  int i;

  if (co == NULL)
    die(" Error: null cluster output structure passed to set_cluster_size()\n");
  if (cid <= 0 || cid > co->nclust)
    die(" Error: invalid cluster id passed to set_cluster_size()\n");
  if (size < 0)
    die(" Error: invalid cluster size passed to set_cluster_size()\n");

  if (co->cmembers[cid-1].members != NULL || co->cmembers[cid-1].sid != NULL)
    die(" Error: trying to redefine cluster size in set_cluster_size()\n");

  co->cmembers[cid-1].csize = size;
  if (size > 0) {
    /* allocate memory for storing member structure IDs */
    co->cmembers[cid-1].sid = (int *) malloc(sizeof(int) * size);
    if (co->cmembers[cid-1].sid == NULL)
      die(" Error: unable to allocate memory\n");

    /* allocate memory for pointers to member structures */
    co->cmembers[cid-1].members = (structure **) malloc(sizeof(structure *) * size);
    if (co->cmembers[cid-1].members == NULL)
      die(" Error: unable to allocate memory\n");
    for (i=0; i<size; i++)
      co->cmembers[cid-1].members[i] = NULL;
  }
}


void add_member_to_cluster(structure **st, int sid, clustout *co, int cid) {
  if (st == NULL)
    die(" Error: null structure pointer passed to add_member_to_cluster()\n");

  if (co == NULL)
    die(" Error: null cluster output structure passed to add_member_to_cluster()\n");
  if (cid <= 0 || cid > co->nclust)
    die(" Error: invalid cluster id passed to add_member_to_cluster()\n");

  if (co->cmembers[cid-1].members == NULL || co->cmembers[cid-1].sid == NULL)
    die(" Error: clustmem structure not yet initialized\n");
  if (co->cmembers[cid-1].added == co->cmembers[cid-1].csize)
    die(" Error: clustmem structure already full, unable to add more members\n");

  /* ok, we should now be safe to add this member to the cluster */
  co->cmembers[cid-1].members[co->cmembers[cid-1].added] = st[sid-1];
  co->cmembers[cid-1].sid[co->cmembers[cid-1].added] = sid;
  co->cmembers[cid-1].added++;
  co->ntotal++;
}


void clean_clustout(clustout *co) {
  int i;

  if (co == NULL)
    return;

  if (co->cmembers != NULL) {
    for (i=0; i<co->nclust; i++) {
      if (co->cmembers[i].members != NULL)
        free(co->cmembers[i].members);

      if (co->cmembers[i].sid != NULL)
        free(co->cmembers[i].sid);
    }
    free(co->cmembers);
  }

  free(co);
}
