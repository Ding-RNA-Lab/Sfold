#include "distlib.h"

#define MAX_BUFFER      1000
#define MAX_CLUSTERS    20

typedef struct clustmem_struct {
  int csize;  /* number of member structures in this cluster */
  int added;  /* number of structures included to the members array */
  int *sid;   /* ID of member structures (values between 1 and 1000) */
  structure **members;
} clustmem;

typedef struct clustout_struct {
  int nclust;  /* total number of clusters in this output */
  int ntotal;  /* total number of structures in all clusters */
  clustmem *cmembers;  /* to store member structures in each cluster */
} clustout;


extern void die(char *err);

extern void build_vector(char *fn, float *elts, int v);
extern float euclidean(float *a, float *b, int n);
extern int find_nsamples(char *bpfile);
extern float *getrowfromvector(float *a, int nrows, int idx);
extern int lookup(int elt, int *array, int size);
extern float sum_across(float *a, int n);


/*
 * Functions to work on the clustout data structure
 */
extern clustout *new_clustout(int nclust);
extern void set_cluster_size(clustout *co, int cid, int size);
extern void add_member_to_cluster(structure **st, int sid, clustout *co, int cid);
extern void clean_clustout(clustout *co);
