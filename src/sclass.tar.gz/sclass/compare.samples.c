/*
 * This program is for comparing structures from two
 * different samples. We will output the IDs of those
 * structures appearing in both samples.
 */

#include <stdio.h>
#include <stdlib.h>

#include "clustlib.h"
//#include "centroid.h"


/* function prototype */
void die(char *err);
void usage(char *pn);


/* program location variables */


/* global variables */


int main(int argc, char *argv[]) {
  int i, j;
  char *bpfile1, *bpfile2;
  structure **sample1, **sample2;
  int nsamples1 = 0, nsamples2 = 0;
  int seqlen = 0;


  if (argc != 4) {
    usage(argv[0]);
    return -1;
  }


  /* read in sequence length from command line */
  seqlen = atoi(argv[1]);
  if (seqlen <= 0)
    die(" Error: invalid sequence length.\n");

  /* read in bp file names from command line */
  bpfile1 = argv[2];
  bpfile2 = argv[3];


  /* determine number of structures in samples */
  nsamples1 = find_nsamples(bpfile1);
  if (nsamples1 == 0)
    die(" Error: zero sample size in file 1\n");
  nsamples2 = find_nsamples(bpfile2);
  if (nsamples2 == 0)
    die(" Error: zero sample size in file 2\n");


  /* now read all structures in the two samples and store them into memory. */
  sample1 = (structure **) malloc(sizeof(structure *) * nsamples1);
  if (sample1 == NULL)
    die(" Error: unable to allocate memory\n");
  for (i=0; i<nsamples1; i++)
    sample1[i] = new_structure();

  if (read_sample(bpfile1, nsamples1, sample1, seqlen) != nsamples1)
    die(" Error: inconsistent sample size\n");

  sample2 = (structure **) malloc(sizeof(structure *) * nsamples2);
  if (sample2 == NULL)
    die(" Error: unable to allocate memory\n");
  for (i=0; i<nsamples2; i++)
    sample2[i] = new_structure();

  if (read_sample(bpfile2, nsamples2, sample2, seqlen) != nsamples2)
    die(" Error: inconsistent sample size\n");


  for (i=0; i<nsamples1; i++)
    for (j=0; j<nsamples2; j++)
      if (find_bpdist(sample1[i], sample2[j]) == 0) {
        printf("%6d = %6d\n", i+1, j+1);
      }

  return 0;
}


/* Subroutines */

void usage(char *pn) {
  printf("Usage: %s <sequence length> <BP file 1> <BP file 2>\n", pn);
  printf("\n");
  return;
}

/**
 * Required cleanup definition, needed to use die
 **/
void cleanup(void) {}
