#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//#include "distlib.h"
#include "clustlib.h"


int find_bpdist(structure *s1, structure *s2) {
  distances dist;

  if (s1 == NULL || s2 == NULL)
    die(" Error: null pointer passed to find_bpdist()\n");

  return find_dist(s1->firstbp, s2->firstbp, &dist);
}


int find_dist(basepair *struct1, basepair *struct2, distances *dist) {
  int d = 0;
  basepair *s1, *s2, *stop;
  int found;

/* Look for base pairs in structure 1 not shared by structure 2 */
  stop = struct2;
  for (s1=struct1; s1!=NULL; s1=s1->next) {
    found = 0;
    for (s2=stop; s2!=NULL; s2=s2->next) {
      if (s1->i == s2->i && s1->j == s2->j) {
        found = 1;
        stop = s2->next;
        break;
      } else if (s1->i < s2->i) {
        stop = s2;
        break;
      }
    }

    if (found == 0)
      d++;
  }

  dist->i = d;

/* Look for base pairs in structure 2 not shared by structure 1 */
  stop = struct1;
  for (s2=struct2; s2!=NULL; s2=s2->next) {
    found = 0;
    for (s1=stop; s1!=NULL; s1=s1->next) {
      if (s1->i == s2->i && s1->j == s2->j) {
        found = 1;
        stop = s1->next;
        break;
      } else if (s2->i < s1->i) {
        stop = s1;
        break;
      }
    }

    if (found == 0)
      d++;
  }

  dist->j = d - dist->i;

  return d;
}


void find_distmatrix(int seqlen, int nsamples, char* infile, int **dist, float **pdiff) {
  int i, j;
  basepair *node, *lastnode;
  distances bpdist;
  structure **st = NULL;

  if (dist == NULL)
    die(" Error: find_distmatrix() failed due to undefined dist\n");

  st = (structure **) malloc(sizeof(structure *) * nsamples);
  if (st == NULL)
    die(" Error: unable to allocate memory\n");
  for (i=0; i<nsamples; i++)
    st[i] = new_structure();

  if (read_sample(infile, nsamples, st, seqlen) != nsamples)
    die(" Error: inconsistent sample size\n");

  /* calculate the distances */
  for (i=0; i<nsamples-1; i++)
    for (j=i+1; j<nsamples; j++) {
      dist[i][j] = find_dist(st[i]->firstbp, st[j]->firstbp, &bpdist);
      dist[j][i] = dist[i][j];
      if (pdiff != NULL) {
        if (st[i]->npairs != 0)
          pdiff[i][j] = 100.0 * bpdist.i / st[i]->npairs;
        else pdiff[i][j] = 0.0;
        if (st[j]->npairs != 0)
          pdiff[j][i] = 100.0 * bpdist.j / st[j]->npairs;
        else pdiff[j][i] = 0.0;
      }
    }

  /* Now starting to free up memory */
  for (i=0; i<nsamples; i++) {
    node = st[i]->firstbp;
    while (node != NULL) {
      lastnode = node;
      node = node->next;
      free(lastnode);
    }
  }
  free(st);
}


int read_sample(char* bpfile, int nsamples, structure **st, int seqlen) {
  FILE *fp;
  int count, i, j;
  char line[MAX_BUFFER];

  if ((fp=fopen(bpfile, "r")) == NULL)
    die(" Error: Unable to open base pair file\n");

  if (st == NULL)
    die(" Error: null structure passed to read_sample()\n");
  for (i=0; i<nsamples; i++)
    if (st[i] == NULL)
      die(" Error: null structure passed to read_sample()\n");

  count = -1;
  while(fgets(line, MAX_BUFFER-1, fp) != NULL) {
    if (strstr(line, "Structure") != NULL || strstr(line, "structure") != NULL 
     || strstr(line, "STRUCTURE") != NULL) {
      count++;
      if (count == nsamples)
        die(" Error: inconsistent sample size\n");
      st[count]->npairs = 0;
      st[count]->firstbp = NULL;
      st[count]->lastbp = NULL;
    } else if (count < 0) {
      continue;
    } else {
      i = j = -1;
      sscanf(line, "%d %d", &i, &j);
      if (i == -1 || j == -1)
        continue;
      if (i > seqlen || j > seqlen)
        die(" Error: inconsistent sequence length\n");

      add_bp_to_structure(i, j, st[count]);
    }
  }
  fclose(fp);

  return (count+1);
}


/*
 * to convert the one dimensional vector index to
 * the two dimensional upper triangular (i,j) indices
 * indices start at 1.
 */
void oned2twod(int k, int *i, int *j, int n) {
  int tmp;

  if (k > n*(n-1)/2)
    die(" Error: 1-d vector index is out of range\n");

  *i = 1;
  tmp = n;

  while (1) {
    tmp -= 1;
    if (k-tmp > 0) {
      (*i)++;
      k -= tmp;
    } else break;
  }

  *j = k + *i;
}


/*
 * to convert the two dimensional upper triangular 
 * (i,j) indices to the one dimensional vector index
 * indices start at 1.
 */
void twod2oned(int i, int j, int *k, int n) {
  *k = n*(i-1) - i*(i+1)/2 + j;
}



/*
 * Functions for handling the structure data type
 */

structure *new_structure(void) {
  structure *st = NULL;

  st = (structure *) malloc(sizeof(structure));
  if (st == NULL)
    die(" Error: unable to allocate memory\n");

  st->npairs = 0;
  st->firstbp = st->lastbp = NULL;

  return st;
}


int read_structure_from_ct(char *ctfile, structure *st) {
  FILE *fp;
  int count, i, j, di1, di2, di3;
  char line[MAX_BUFFER], dc1;

  if (st == NULL)
    die(" Error: NULL structure passed to read_structure_from_ct()\n");

  if ((fp=fopen(ctfile, "r")) == NULL)
    die(" Error: Unable to open GCG connect file\n");

  count = 0;
  while(fgets(line, MAX_BUFFER-1, fp) != NULL) {
    i = j = di1 = di2 = di3 = -1;
    sscanf(line, "%d %c %d %d %d %d", &i, &dc1, &di1, &di2, &j, &di3);

    if (i <= 0 || di1 != i-1 || di2 != i+1 || di3 != i || i >= j)
      continue;

    add_bp_to_structure(i, j, st);
    count++;
  }

  fclose(fp);

  /* return the number of BPs read from file */
  return count;  
}


void add_bp_to_structure(int x, int y, structure *st) {
  basepair *node;

  if (st == NULL)
    die(" Error: NULL structure passed to add_bp_to_structure()\n");
  if (x >= y)
    die(" Error: invalid base pair passed to add_bp_to_structure()\n");

  node = (basepair *) malloc(sizeof(basepair));
  if (node == NULL)
    die(" Error: unable to allocate memory\n");

  node->i = x;
  node->j = y;
  node->next = NULL;

  if (st->lastbp != NULL) {
    /* there is at least one base pair in the structure */
    st->lastbp->next = node;
    st->lastbp = node;
  } else if (st->firstbp == NULL)
    /* no base pair in the structure, we are adding the first one */
    st->firstbp = st->lastbp = node;

  st->npairs++;
}


void print_structure(FILE *fp, structure *st) {
  basepair *node;

  if (st == NULL)
    die(" Error: NULL structure passed to print_structure()\n");
  if (fp == NULL)
    die(" Error: NULL file pointer passed to print_structure()\n");

  node = st->firstbp;
  while (node != NULL) {
    fprintf(fp, "%d %d\n", node->i, node->j);
    node = node->next;
  }
}

/*
 * Write structure to file in GCG connect format. Parameters are:
 * - output filename
 * - structure name
 * - pointer to structure
 * - free energy
 * - sequence length
 * - sequence data
 */
void print_structure_ct(char *fn, char *sn, structure *st, float fe, int len, char *seq) {
  basepair *node;
  int *fbp;
  FILE *outfp;
  int i, nextbase;

  if (fn == NULL)
    die(" Error: NULL file name passed to print_structure_ct()\n");
  if (sn == NULL)
    die(" Error: NULL structure name passed to print_structure_ct()\n");
  if (st == NULL)
    die(" Error: NULL structure passed to print_structure_ct()\n");
  if (len <= 0)
    die(" Error: invalid sequence length passed to print_structure_ct()\n");
  if (seq == NULL)
    die(" Error: NULL sequence data passed to print_structure_ct()\n");

  fbp = (int *) calloc((size_t) len+1, sizeof(int));
  if (fbp == NULL)
    die(" Error: failed to allocate memory in print_structure_ct()\n");

  node = st->firstbp;
  while (node != NULL) {
    fbp[node->i] = node->j;
    fbp[node->j] = node->i;
    node = node->next;
  }

  outfp = fopen(fn, "w");
  if (outfp == NULL)
    die(" Error: unable to create file for writing ensemble centroid\n");

  /* write header lines */
  fprintf(outfp, "SFOLD of:  [initially %.2f]    %s Check: 0 from: 1 to: %d\n",
    fe, sn, len);
  fprintf(outfp, "Length:  %d Energy:  %.2f ..\n", len, fe);
  for (i=1; i<=len; i++) {
    nextbase = ((i+1 > len) ? 0 : (i+1));
    fprintf(outfp, "%5d %c %5d %5d %5d %5d\n", i, seq[i-1], i-1, nextbase, fbp[i], i);
  }
  fclose(outfp);

  free(fbp);
}


void clean_structure(structure *st) {
  basepair *node, *prev;

  if (st == NULL)
    return;

  node = st->firstbp;
  while (node != NULL) {
    prev = node;
    node = node->next;
    free(prev);
  }
  st->firstbp = st->lastbp = NULL;

  free(st);
}

