typedef struct basepair_struct {
  int i;
  int j;
  struct basepair_struct *next;
} basepair;

typedef struct structure_struct {
  int npairs;
  basepair *firstbp;
  basepair *lastbp;
} structure;

typedef struct distances_struct {
  int i;
  int j;
} distances;


extern void die(char *err);

extern int find_bpdist(structure *s1, structure *s2);
extern int find_dist(basepair *struct1, basepair *struct2, distances *dist);
extern void find_distmatrix(int seqlen, int nsamples, char* infile, int **dist, float **pdiff);
extern int read_sample(char* bpfile, int nsamples, structure **st, int seqlen);
extern void oned2twod(int k, int *i, int *j, int n);
extern void twod2oned(int i, int j, int *k, int n);


/*
 * Functions for handling the structure data type
 */

extern structure *new_structure(void);
extern int read_structure_from_ct(char *ctfile, structure *st);
extern void add_bp_to_structure(int x, int y, structure *st);
extern void print_structure(FILE *fp, structure *st);
extern void print_structure_ct(char *fn, char *sn, structure *st, float fe,
  int len, char *seq);
extern void clean_structure(structure *st);

