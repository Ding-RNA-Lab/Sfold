#include <stdio.h>
#include <string.h>
#include <stdlib.h>
//#include "distlib.h"
#include "clustlib.h"

void die(char *err);
void usage(char *pn);

int main(int argc, char *argv[]) {
  FILE *outfp1, *outfp2, *outfp3;
  int nsamples, i, j, n;
  int **dist;
  float **pdiff;

  if (argc != 6) {
    usage(argv[0]);
    return -1;
  }

  n = atoi(argv[1]);
  if (n <= 0) {
    printf("Invalid sequence length\n");
    return -1;
  }

  nsamples = find_nsamples(argv[2]);

  /* allocate memory and initialize array to store distances */
  dist = (int **) malloc(sizeof(int *) * nsamples);
  if (dist == NULL)
    die(" Error: unable to allocate memory\n");

  for (i=0; i<nsamples; i++) {
    dist[i] = (int *) malloc(sizeof(int) * nsamples);
    if (dist[i] == NULL)
      die(" Error: unable to allocate memory\n");
  }
  for (i=0; i<nsamples; i++)
    dist[i][i] = 0;


  /* allocate memory and initialize array to store percentage differences */
  pdiff = (float **) malloc(sizeof(float *) * nsamples);
  if (pdiff == NULL)
    die(" Error: unable to allocate memory\n");
  for (i=0; i<nsamples; i++) {
    pdiff[i] = (float *) malloc(sizeof(float) * nsamples);
    if (pdiff[i] == NULL)
      die(" Error: unable to allocate memory\n");
  }
  for (i=0; i<nsamples; i++)
    pdiff[i][i] = 0.0;

  find_distmatrix(n, nsamples, argv[2], dist, pdiff);

  outfp1 = fopen(argv[3], "w");
  if (outfp1 == NULL) {
    fprintf(stderr, " Error: unable to open output file %s\n", argv[3]);
    return -1;
  }
  for (i=0; i<nsamples; i++) {
    for (j=0; j<nsamples; j++)
      fprintf(outfp1, "%d ", dist[i][j]);
    fprintf(outfp1, "\n");
  }
  fclose(outfp1);

  outfp2 = fopen(argv[4], "w");
  if (outfp2 == NULL) {
    fprintf(stderr, " Error: unable to open output file %s\n", argv[4]);
    return -1;
  }
  for (i=0; i<nsamples; i++) {
    for (j=0; j<nsamples; j++)
      fprintf(outfp2, "%6.2f ", pdiff[i][j]);
    fprintf(outfp2, "\n");
  }
  fclose(outfp2);

  outfp3 = fopen(argv[5], "w");
  if (outfp3 == NULL) {
    fprintf(stderr, " Error: unable to open output file %s\n", argv[5]);
    return -1;
  }
  for (i=0; i<nsamples; i++)
    for (j=i+1; j<nsamples; j++)
      fprintf(outfp3, "%d ", dist[i][j]);
  fprintf(outfp3, "\n");
  fclose(outfp3);


  /* Now starting to free up memory */
  for (i=0; i<nsamples; i++) {
    free(dist[i]);
    free(pdiff[i]);
  }
  free(dist);
  free(pdiff);

  return 0;
}


void usage(char *pn) {
  printf("Usage: %s <sequence_length> <infile> <outfile1> <outfile2> <outfile3>\n", pn);
  printf("  where <infile>    = Base pair file from Sfold\n");
  printf("        <outfile1>  = Output file to store the distance matrix\n");
  printf("        <outfile2>  = Output file to store the matrix of percentages\n");
  printf("                      of BPs not shared between every 2 structures\n");
  printf("        <outfile3>  = Output file to store the dissimilarity vector\n");
  printf("\n");
  return;
}

/**
 * Required cleanup definition, needed to use die
 **/
void cleanup(void) {}
