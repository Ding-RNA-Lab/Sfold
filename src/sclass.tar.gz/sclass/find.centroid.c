#include <stdio.h>
#include <stdlib.h>

#define DEBUG_MODE	0

struct stack_elts {
  int i, j;
};

struct stack {
  int num;
  struct stack_elts *stptr;
};

void cleanup(void);
void die(char *err);
void enter_scores(char *fn);
int fill(int i, int j);
int find_score(int i, int j);
int is_stack_empty(struct stack *s);
void pop(struct stack *s, int *i, int *j);
void push(struct stack *s, int i, int j);
void traceback(void);
void usage(char *pn);

int seqlen;
int *fbp;
int **scores, **minmatrix;

int main(int argc, char *argv[]) {
  int i, j, min_score;

  if (argc != 3) {
    usage(argv[0]);
    die("");
  }
  seqlen = atoi(argv[2]);
  if (seqlen <= 0)
    die(" Error: invalid sequence length\n");

  /* allocate memory and initialize array to store minimum */
  minmatrix = (int **) malloc(sizeof(int *) * (seqlen+1));
  if (minmatrix == NULL)
    die(" Error: unable to allocate memory\n");

  for (i=0; i<seqlen+1; i++) {
    minmatrix[i] = (int *) malloc(sizeof(int) * (seqlen+1));
    if (minmatrix[i] == NULL)
      die(" Error: unable to allocate memory\n");
    for (j=0; j<seqlen+1; j++)
      minmatrix[i][j] = 0;
  }

  enter_scores(argv[1]);

  for (i=1; i<seqlen+1; i++)
    for (j=i+1; j<seqlen+1; j++)
      fill(i, j);

  min_score = fill(1, seqlen);

  if (DEBUG_MODE) {
    printf("min score = %d\n\n", min_score);

    for (i=1; i<seqlen+1; i++) {
      for (j=1; j<seqlen+1; j++)
        printf("%d ", scores[i][j]);
      printf("\n");
    }
    printf("\n");

    for (i=1; i<seqlen+1; i++) {
      for (j=1; j<seqlen+1; j++)
        printf("%d ", minmatrix[i][j]);
      printf("\n");
    }
    printf("\n");
  }

  traceback();

  for (i=1; i<seqlen+1; i++)
    if (fbp[i] != 0 && fbp[i] > i)
      printf("%d %d\n", i, fbp[i]);

  cleanup();

  return 0;
}


/** Subroutines **/

void cleanup(void) {
  int i;

  if (scores) {
    for (i=0; i<seqlen+1; i++)
      if (scores[i]) free(scores[i]);
    free(scores);
  }
  if (minmatrix) {
    for (i=0; i<seqlen+1; i++)
      if (minmatrix[i]) free(minmatrix[i]);
    free(minmatrix);
  }
  if (fbp)
    free(fbp);
}

void enter_scores(char *fn) {
  FILE *fp;
  int i, j, count, base;

  /* allocate memory and initialize array to store scores */
  scores = (int **) malloc(sizeof(int *) * (seqlen+1));
  if (scores == NULL)
    die(" Error: unable to allocate memory\n");

  for (i=0; i<seqlen+1; i++) {
    scores[i] = (int *) malloc(sizeof(int) * (seqlen+1));
    if (scores[i] == NULL)
      die(" Error: unable to allocate memory\n");
    for (j=0; j<seqlen+1; j++)
      scores[i][j] = 0;
  }


  if ((fp=fopen(fn, "r")) == NULL)
    die(" Error: unable to open bp count file\n");

  while (fscanf(fp, "%d %d %d %d", &i, &j, &count, &base) != EOF) {
    if (i > seqlen || j > seqlen)
      die(" Error: sequence length and input file do not match\n");

//    scores[i][j] = 0 - count;
    scores[i][j] = base - 2 * count;

    if (fgetc(fp) == EOF)
      break;
  }

  fclose(fp);
}

int fill(int i, int j) {
  int min, k, test;

  /* stopping conditions */
  if (i<1 || j<1 || i>seqlen || j>seqlen || i>=j || j-i<4)
    return 0;

  /* return value if already computed */
  if (minmatrix[j][i] == 1)
    return minmatrix[i][j];

  min = fill(i, j-1);

  test = fill(i+1, j-1) + find_score(i, j);
  if (test < min)
    min = test;

  for (k=i+1; k<j-3; k++) {
    test = fill(i, k-1) + fill(k+1, j-1) + find_score(k, j);
    if (test < min)
      min = test;
  }
  minmatrix[i][j] = min;
  minmatrix[j][i] = 1;

  return min;
}

int find_score(int i, int j) {
  int tmp;

  if (i < j)
    return scores[i][j];
  else return scores[j][i];
}

int is_stack_empty(struct stack *s) {
  if (s) {
    if (s->num <= 0)
      return 1;
    else return 0;
  }
}

void pop(struct stack *s, int *i, int *j) {
  struct stack_elts *ptr;

  if (s) {
    if (is_stack_empty(s))
      fprintf(stderr, " Error: unable to pop from an empty stack\n");
    else {
      s->num--;
      *i = s->stptr[s->num].i;
      *j = s->stptr[s->num].j;
      ptr = (struct stack_elts *) realloc(s->stptr, sizeof(struct stack_elts) * s->num);
      s->stptr = ptr;
    }
  }
}

void push(struct stack *s, int i, int j) {
  struct stack_elts *ptr;

  if (s) {
    s->num++;
    ptr = (struct stack_elts *) realloc(s->stptr, sizeof(struct stack_elts) * s->num);
    if (ptr == NULL)
      fprintf(stderr, " Error: unable to reallocate stack memory\n");
    else {
      s->stptr = ptr;
      s->stptr[s->num-1].i = i;
      s->stptr[s->num-1].j = j;
    }
  }
}

void traceback(void) {
  struct stack bps;
  int i, j, k;

  bps.num = 0;
  bps.stptr = NULL;

  fbp = (int *) calloc((seqlen+1), sizeof(int));
  if (fbp == NULL)
    die(" Error: unable to allocate memory\n");

  push(&bps, 1, seqlen);

  while (!is_stack_empty(&bps)) {
    pop(&bps, &i, &j);
    while (i != j) {
      if (minmatrix[i][j] == minmatrix[i][j-1])
        j--;
      else if (minmatrix[i][j] == (minmatrix[i+1][j-1]+find_score(i, j))) {
        fbp[i] = j;
        fbp[j] = i;
        i++;
        j--;
      } else {
        for (k=j-4; k>i; k--) {
          if (minmatrix[i][j] == (minmatrix[i][k-1]+minmatrix[k+1][j-1]+find_score(k, j)))
            break;
        }
        if (k == i) {
          if (DEBUG_MODE) {
            printf("(i,j) = (%d,%d)\n", i, j);
            printf("W(i,j) = %d\n\n", minmatrix[i][j]);
            printf("W(i,j-1) = %d\n", minmatrix[i][j-1]);
            printf("W(i+1,j-1)+e(i,j) = %d\n", minmatrix[i+1][j-1]+find_score(i, j));
          }

          die(" Error: unable to trace back previous step\n");
        }
        fbp[k] = j;
        fbp[j] = k;
        push(&bps, k+1, j-1);
        j = k - 1;
      }
    }
  }
}


void usage(char *pn) {
  printf("Usage: %s <base pair count file> <sequence length>\n", pn);
}
