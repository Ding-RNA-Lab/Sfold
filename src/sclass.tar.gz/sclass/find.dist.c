/*
 * todo:
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <math.h>
#include <unistd.h>
#include "distlib.h"

#define MAX_PATHSIZE	1024
#define MAX_BUFFER	1000
#define DEF_BPFILE	"./bp.out"
#define DEF_FEFILE	"./fe.out"
#define DEF_GCGFILE	"./mfold.ct"
#define DEF_PROBFILE	"./bprob.out"

struct ProgArgs {
  char *bpfile;
  char *fefile;
  char *gcgfile;
  char *probfile;
  int sid;

  char *my_bpfile;
  char *my_fefile;
};

/* function prototype */
void cleanup(void);
void die(char *err);
int find_nsamples(void);
int init_env(char *pn);
struct ProgArgs *setArgs(int argc, char *argv[]);
void usage(char *pn);


/* program location variables */
char gcg2bp[MAX_PATHSIZE];


/* global variables */
struct ProgArgs *args = NULL;
int **dist;
float **pdiff;
int seqlen = 0, nsamples = 0;
float mfold_mfe = 0.0;
char *fileid = NULL;

int main(int argc, char *argv[]) {
  int i;
  FILE *cmdptr;
  char *ptrtmp;
  char buf[MAX_BUFFER], cmd[MAX_BUFFER];

  if ((args = setArgs(argc, argv)) == NULL) {
    usage(argv[0]);
    return -1;
  }
  signal(SIGCHLD, SIG_IGN);

  fileid = tempnam("./", "cluster");
  sprintf(buf, "%s.xx", fileid);
  args->my_bpfile = (char *) malloc(sizeof(char) * (strlen(buf)+1));
  args->my_fefile = (char *) malloc(sizeof(char) * (strlen(buf)+1));
  sprintf(args->my_bpfile, "%s.bp", fileid);
  sprintf(args->my_fefile, "%s.fe", fileid);

  if (init_env(argv[0]) < 0)
    return -2;

  /* determine sequence length from bprob.out */
  sprintf(cmd, "head -3 %s | tail -1", args->probfile);
  if ((cmdptr=popen(cmd, "r")) == NULL)
    die("popen() failed.");
  if (!fgets(buf, MAX_BUFFER-1, cmdptr))
    die("command produced no output.");
  seqlen = atoi(buf);
  pclose(cmdptr);
  if (seqlen <= 0)
    die("invalid sequence length.");


  /* prepare the distance matrix file, including the MFE structure from mfold */
  sprintf(cmd, "cp %s %s", args->bpfile, args->my_bpfile);
  // I cannot check exit status of system because it is different on solaris and linux :(
  system(cmd);
  sprintf(cmd, "cp %s %s", args->fefile, args->my_fefile);
  system(cmd);
  sprintf(cmd, "%s %s >> %s", gcg2bp, args->gcgfile, args->my_bpfile);
  system(cmd);

  nsamples = find_nsamples();
  if (nsamples == 0)
    die("zero sample size");
  if (args->sid > nsamples)
    die("base structure ID greater than sample size");

  /* grep the minimum free energy from the mfold optimal structure
     and concatenate that to the end of our fe.out */
  sprintf(cmd, "grep initially %s", args->gcgfile);
  if ((cmdptr=popen(cmd, "r")) == NULL)
    die("popen() failed.");
  if (!fgets(buf, MAX_BUFFER-1, cmdptr))
    die("command produced no output.");
  pclose(cmdptr);
  if ((ptrtmp=strstr(buf, "initially")) != NULL) {
    ptrtmp = strstr(ptrtmp, " ");
    mfold_mfe = atof(ptrtmp);
    sprintf(cmd, "echo \"%d    %.2f\" >> %s", nsamples, mfold_mfe, args->my_fefile);
    // I cannot check exit status of system because it is different on solaris and linux :(
    system(cmd);
  }

  /* allocate memory and initialize array to store distances */
  dist = (int **) malloc(sizeof(int *) * nsamples);
  if (dist == NULL)
    die("unable to allocate memory");

  for (i=0; i<nsamples; i++) {
    dist[i] = (int *) malloc(sizeof(int) * nsamples);
    if (dist[i] == NULL)
      die(" Error: unable to allocate memory\n");
  }
  for (i=0; i<nsamples; i++)
    dist[i][i] = 0;

  /* allocate memory and initialize array to store percentage differences */
  pdiff = (float **) malloc(sizeof(float *) * nsamples);
  if (pdiff == NULL)
    die("unable to allocate memory");
  for (i=0; i<nsamples; i++) {
    pdiff[i] = (float *) malloc(sizeof(float) * nsamples);
    if (pdiff[i] == NULL)
      die("unable to allocate memory");
  }
  for (i=0; i<nsamples; i++)
    pdiff[i][i] = 0.0;

  find_distmatrix(seqlen, nsamples, args->my_bpfile, dist, pdiff);

  for (i=0; i<nsamples; i++) {
    printf("%d %d\n", i+1, dist[i][args->sid-1]);
  }

  cleanup();

  return 0;
}


/* Subroutines */

void cleanup(void) {
  int i;
  char cmd[MAX_BUFFER];

  if (fileid) {
  }

  if (args) {
    if (args->my_bpfile) {
      sprintf(cmd, "rm -f %s", args->my_bpfile);
      // I cannot check exit status of system because it is different on solaris and linux :(
      system(cmd);
    }
    if (args->my_fefile) {
      sprintf(cmd, "rm -f %s", args->my_fefile);
      // I cannot check exit status of system because it is different on solaris and linux :(
      system(cmd);
    }

    if (args->bpfile) free(args->bpfile);
    if (args->fefile) free(args->fefile);
    if (args->gcgfile) free(args->gcgfile);
    if (args->probfile) free(args->probfile);
    if (args->my_bpfile) free(args->my_bpfile);
    if (args->my_fefile) free(args->my_fefile);

    free(args);
  }

  if (dist) {
    for (i=0; i<nsamples; i++)
      if (dist[i]) free(dist[i]);
    free(dist);
  }
  if (pdiff) {
    for (i=0; i<nsamples; i++)
      if (pdiff[i]) free(pdiff[i]);
    free(pdiff);
  }
}


int init_env(char *pn) {
  char *m;
  char path[MAX_PATHSIZE];
  int i;

  if ((m=strrchr(pn, '/')) != NULL) {
    for (i=0; i<(strlen(pn)-strlen(m)); i++)
      path[i] = pn[i];
    path[i++] = '/';
    path[i] = '\0';
  }

  strcpy(gcg2bp, path);
  strcat(gcg2bp, "gcg2bp.pl");

  /* check the existence of the external script */
  if (access(gcg2bp, F_OK) != 0) {
    /* it does not exist! */
    fprintf(stderr," Error: unable to locate script file '%s'!\n", gcg2bp);
    return -1;
  }

  return 0;
}


struct ProgArgs *setArgs(int argc, char *argv[]) {
  struct ProgArgs *a = NULL;
  int i;

  a = (struct ProgArgs *) malloc(sizeof(struct ProgArgs));
  if (a == NULL) {
    fprintf(stderr," Error: failed to allocate memory for program arguments\n");
    return NULL;
  }

  /* Initialize structure elements */
  a->bpfile = NULL;
  a->fefile = NULL;
  a->gcgfile = NULL;
  a->probfile = NULL;
  a->sid = 0;
  a->my_bpfile = NULL;
  a->my_fefile = NULL;

  /* Do the argument matching here... */
  if (argc < 2) {
    cleanup();
    return NULL;
  }

  for (i=1; i<argc; i++)
    if (strcmp(argv[i], "-h") == 0) {
      cleanup();
      return NULL;
    }

  i = 1;
  while (i < argc) {
    if (argv[i][0] == '-') {
      /* this is an option field */
      if (i >= argc-1) {
        fprintf(stderr," Error: argument to '%s' is missing\n", argv[i]);
        cleanup();
        return NULL;
      }

      if (strcmp(argv[i]+1,"b") == 0) {
        a->bpfile = (char *) malloc(sizeof(char) * (strlen(argv[++i])+1));
        strcpy(a->bpfile, argv[i]);

      } else if (strcmp(argv[i]+1,"f") == 0) {
        a->fefile = (char *) malloc(sizeof(char) * (strlen(argv[++i])+1));
        strcpy(a->fefile, argv[i]);

      } else if (strcmp(argv[i]+1,"i") == 0) {
        a->sid = atoi(argv[++i]);

      } else if (strcmp(argv[i]+1,"m") == 0) {
        a->gcgfile = (char *) malloc(sizeof(char) * (strlen(argv[++i])+1));
        strcpy(a->gcgfile, argv[i]);

      } else if (strcmp(argv[i]+1,"p") == 0) {
        a->probfile = (char *) malloc(sizeof(char) * (strlen(argv[++i])+1));
        strcpy(a->probfile, argv[i]);

      } else {
        fprintf(stderr," Error: unknown argument '%s'\n", argv[i]);
        cleanup();
        return NULL;
      }

    } else {
      fprintf(stderr," Error: unknown argument '%s'\n", argv[i]);
      cleanup();
      return NULL;
    }

    i++;
  }

  if (a->sid <= 0) {
    fprintf(stderr," Error: invalid base structure ID\n");
    cleanup();
    return NULL;
  }

  if (a->bpfile == NULL) {
    a->bpfile = (char *) malloc(sizeof(char) * (strlen(DEF_BPFILE)+1));
    strcpy(a->bpfile, DEF_BPFILE);
  }
  if (a->fefile == NULL) {
    a->fefile = (char *) malloc(sizeof(char) * (strlen(DEF_FEFILE)+1));
    strcpy(a->fefile, DEF_FEFILE);
  }
  if (a->gcgfile == NULL) {
    a->gcgfile = (char *) malloc(sizeof(char) * (strlen(DEF_GCGFILE)+1));
    strcpy(a->gcgfile, DEF_GCGFILE);
  }
  if (a->probfile == NULL) {
    a->probfile = (char *) malloc(sizeof(char) * (strlen(DEF_PROBFILE)+1));
    strcpy(a->probfile, DEF_PROBFILE);
  }

  return a;
}


void usage(char *pn) {
  printf("Usage: %s [options]...\n", pn);
  printf("Options:\n");
  printf("  -b <string>         Base pair file from Sfold [default=%s]\n", DEF_BPFILE);
  printf("  -f <string>         Free energy file from Sfold [default=%s]\n", DEF_FEFILE);
  printf("  -h                  Display this information\n");
  printf("  -i <integer>        Base structure ID (required)\n");
  printf("  -m <string>         Mfold optimal structure in GCG connect format [default=%s]\n", DEF_GCGFILE);
  printf("  -p <string>         bprob.out from Sfold for Boltzmann Prob. [default=%s]\n", DEF_PROBFILE);
  printf("\n");
  return;
}

