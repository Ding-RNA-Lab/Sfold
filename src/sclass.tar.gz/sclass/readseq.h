/*
 * This file contains functions to read sequence data
 */


/* Function prototypes from readseq.c */
extern FILE *file_open(char *p, char *m);
extern int getPlainlen(char *fn);
extern int getCTlen(char *fn);
extern int getFASTAlen(char *fn);
extern int readFASTA(char *fn, int n, char *s);
