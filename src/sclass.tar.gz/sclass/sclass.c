
/*
 * This is the main program for Sfold clustering.
 * 2008-07-02 this program is now free of expect library dependency.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <math.h>
#include <sys/wait.h>
#include <unistd.h>

#include "clustlib.h"
#include "centroid.h"
#include "../version.h"
#include "readseq.h"

#define IS_DIANA(x)	(strcasecmp(x, "divisive") == 0) ? 1 : 0
#define MFE_DEFINED(x)	(x == NULL) ? 0 : 1

#define MAX_PATHSIZE	1024
#define SCLASS_INFINITY	99999
#define DEF_BPFILE	"./bp.out"
#define DEF_FEFILE	"./fe.out"
#define DEF_PROBFILE	"./bprob.out"
#define DEF_METHOD	"divisive"
#define DEF_WRITE_MOREFILES	1
#define DEF_ECDIR		"."
#define DEF_CCDIR		"./clusters"

/* Uncomment the following line to produce more output statistics */
//#define VERBOSE_OUTPUT
#define ROUT_BUFF_SIZE 32768

/* structure for storing input command line parameters */
struct ProgArgs {
	char *bpfile;
	char *fefile;
	char *gcgfile;
	char *probfile;
	char *seqfile;
	char *method;
	int nclusters;
	int write_morefiles;
	char *ecdir;
	char *ccdir;
};

/* function prototype */
void calculate_distmatrix(int n);
void cleanup(void);
void die(char *err);
void init_env(char *pn);
void loadenv(void);
int read_fe(char *fefile, int nsamples, float *fe);
struct ProgArgs *setArgs(int argc, char *argv[]);
void sigint(int sig);
void usage(char *pn);

/* environment variables from getenv() */
char *SFOLDBIN, *SFOLDPAR;
char *BPROBEXE;
char *PATH_AWK, *PATH_GREP, *PATH_R;

/* global variables */
struct ProgArgs *args = NULL;
int nsamples = 0;
int **dist;
float **pdiff = NULL;
float mfold_mfe = 0.0, optimal_ch = 0.0, ch_index;
char *fileid = NULL;
char mfold_mfe_bprob[20];

int main(int argc, char *argv[]) {
	int i, j, k, x, itmp, rsize;
	int min_fe_pos, mfold_mfe_grp=-1, dominant_grp=0;
	int istart, iend;
	FILE *cmdptr, *outfp;
	FILE *fpFromR;	//part of the anti-expect adaptation
	FILE *rpfp;		//part of the anti-expect adaptation
	int red;		//part of the anti-expect adaptation
	char *ptrtmp;
	char buf[MAX_BUFFER], cmd[MAX_BUFFER];
	char rbuf[ROUT_BUFF_SIZE];	//part of the anti-expect adaptation
	int *min_fe_struct, **maxd_matrix, **mind_matrix;
	float **avgd_matrix;
	float within_clusters = 0.0, between_clusters = 0.0, min_fe, ftmp;
	float max_dist, avg_dist, min_dist, std_dist, myprob, dominant_prob=0.0;

	structure **sample;
	float *sample_fe;
	structure *ecentroid, *mfest=NULL;
	structure *ccentroid[MAX_CLUSTERS], *savedcc[MAX_CLUSTERS];
	int *bpcount;
	int mfe_cc_closest_dist, mfe_cc_closest_id, cradius;
	clustout *bestco = NULL, *thisco;
	char *seq;
	int seqlen = 0, vsize = 0, optimal_k = 0;

	printf("\n%s, Version %s-%s\n", PROGRAM_TITLE, VERSION, COMPILE_DATE);
	printf("  <Structure clustering module>\n\n");
	fflush(stdout);

	if ((args = setArgs(argc, argv)) == NULL) {
		cleanup();
		return -1;
	}

	//  signal(SIGCHLD, SIG_IGN);
	signal(SIGINT, sigint);

	fileid = tempnam("./", "cluster");

	if (args->nclusters <= 0 || args->nclusters > 50) {
		istart = 2;
		iend = MAX_CLUSTERS;
	} else {
		istart = iend = args->nclusters;
	}

	init_env(argv[0]);
	loadenv();

	/* determine sequence length */
	seqlen = getFASTAlen(args->seqfile);
	if (seqlen <= 0)
		die("unable to determine sequence length from FASTA file.");
	seq = (char *) malloc(sizeof(char) * (seqlen+1));
	if (seq == NULL)
		die("failed to allocate memory for sequence data");
	/* read sequence data */
	if (readFASTA(args->seqfile, seqlen, seq) != seqlen)
		die("inconsistent data length from sequence file");
	seq[seqlen] = '\0';

	/* determine sequence length from bprob.out */
	/*
	 sprintf(cmd, "head -3 %s | tail -1", args->probfile);
	 if ((cmdptr=popen(cmd, "r")) == NULL)
	 die(" Error: popen() failed.\n");
	 fgets(buf, MAX_BUFFER-1, cmdptr);
	 seqlen = atoi(buf);
	 pclose(cmdptr);
	 if (seqlen <= 0)
	 die(" Error: invalid sequence length.\n");
	 */

	/* size of a distance row vector */
	vsize = (seqlen-1) * seqlen / 2;

	/* determine number of structures in this sample */
	nsamples = find_nsamples(args->bpfile);
	if (nsamples == 0)
		die("zero sample size");
	if (nsamples < MAX_CLUSTERS)
		die("sample size smaller than maximum number of clusters");

	/* check if the MFE structure is defined; if not, skip this section */
	if (MFE_DEFINED(args->gcgfile)) {

		/* input the MFE structure from file */
		mfest = new_structure();
		read_structure_from_ct(args->gcgfile, mfest);

		/* grep the free energy from the mfold optimal structure */
		sprintf(cmd, "%s initially %s", PATH_GREP, args->gcgfile);
		if ((cmdptr=popen(cmd, "r")) == NULL)
			die("popen() failed.");
		if (!fgets(buf, MAX_BUFFER-1, cmdptr))
		  die("cmd produced no output");
		pclose(cmdptr);
		if ((ptrtmp=strstr(buf, "initially")) != NULL) {
			ptrtmp = strstr(ptrtmp, " ");
			mfold_mfe = atof(ptrtmp);
		}
		/* and compute the Boltzmann probability of the MFE structure also */
		sprintf(cmd, "%s %s %.2f", BPROBEXE, args->probfile, mfold_mfe);
		if ((cmdptr=popen(cmd, "r")) == NULL)
			die("popen() failed.");
		if (!fgets(mfold_mfe_bprob, 19, cmdptr))
		  die("cmd produced no output");
		pclose(cmdptr);

	}

	/* now calculate the input matrix to R diana() function */
	calculate_distmatrix(seqlen);

	/* print distance matrix to a file so that R can take this file as the input */
	sprintf(buf, "%s.dm", fileid);
	outfp = fopen(buf, "w");
	if (outfp == NULL)
		die("unable to open distance matrix file for output");
	for (i=0; i<nsamples; i++) {
		for (j=0; j<nsamples; j++)
			fprintf(outfp, "%d ", dist[i][j]);
		fprintf(outfp, "\n");
	}
	fclose(outfp);

	/*
	 * 20061107: we updated this further so that the MFE is not compulsory
	 * anymore. If it's provided, then we will determine which cluster it
	 * should be in; if it's not, we just skip it. This scheme is adopted
	 * while we are preparing to distribute the Sfold binaries, cuz we
	 * cannot bundle mfold's executable with our binaries.
	 */
	/*
	 * ok, we read all structures in the sample and store them into memory.
	 * note that we are reading 1000 structures here, excluding the MFE.
	 * the MFE structure was included but it's now removed from the clustering
	 * procedures. We will determine where the MFE is located later manually.
	 * This is to ensure that CH index is purely for our sample only and the
	 * MFE structure plays no part in affecting the outcome.
	 */
	sample = (structure **) malloc(sizeof(structure *) * nsamples);
	if (sample == NULL)
		die("unable to allocate memory");
	for (i=0; i<nsamples; i++)
		sample[i] = new_structure();

	if (read_sample(args->bpfile, nsamples, sample, seqlen) != nsamples)
		die("inconsistent sample size");

	/* read in free energies of all sampled structures */
	sample_fe = (float *) malloc(sizeof(float) * nsamples);
	if (sample_fe == NULL)
		die("unable to allocate memory");
	if (read_fe(args->fefile, nsamples, sample_fe) != nsamples)
		die("inconsistent number of entries in free energy file");

	/* allocate memory for base-pair frequency count vector */
	bpcount = (int *) calloc(sizeof(int), vsize);
	if (bpcount == NULL)
		die(" Error: unable to allocate memory\n");

	/*First compute the base pair frequency matrix */
	compute_bpcount(sample, nsamples, bpcount, seqlen);

	/* Then we determine the ensemble centroid by looking at the bpcount matrix */
	ecentroid = compute_centroid(bpcount, seqlen, nsamples);

	/* write ensemble centroid in base-pair format */
	sprintf(buf, "%s/ecentroid.bp", args->ecdir);
	outfp = fopen(buf, "w");
	if (outfp == NULL)
		die("unable to create file for writing ensemble centroid");
	fprintf(outfp, "Structure 1\n");
	print_structure(outfp, ecentroid);
	fclose(outfp);

	/* determine free energy of ensemble centroid */
	sprintf(
			cmd,
			"%s/findfe -p %s -f 2 -s %s %s/ecentroid.bp | %s Free | %s '{print $4}'",
			SFOLDBIN, SFOLDPAR, args->seqfile, args->ecdir, PATH_GREP, PATH_AWK);
	if ((cmdptr=popen(cmd, "r")) == NULL)
		die("popen() failed.");
	if (!fgets(buf, MAX_BUFFER-1, cmdptr))
		  die("cmd produced no output");
	ftmp = atof(buf);
	pclose(cmdptr);

	/* write ensemble centroid in GCG connect format */
	sprintf(buf, "%s/ecentroid.ct", args->ecdir);
	print_structure_ct(buf, "Ensemble Centroid", ecentroid, ftmp, seqlen, seq);

	/*
	 * check to see if all sampled structures are the same; if so,
	 * we will skip the clustering procedure, print a message and
	 * quit
	 */
	itmp = 0;
	for (i=0; i<nsamples-1; i++) {
		itmp += find_bpdist(sample[i], sample[i+1]);
		if (itmp)
			break;
	}
	if (itmp == 0) {
		/* all structures are the same! */
		printf("Sequence length            = %d\n", seqlen);
		printf("Optimal number of clusters = 1\n\n");

		printf("All sampled structures are identical.\n");
		printf("There is no need to run clustering.\n\n");

		cleanup();

		return 0;
	}
	
	/* open expect substitute version 2 */	
	sprintf(cmd, "%s --vanilla  > /dev/null", PATH_R);
	if ((rpfp=popen(cmd, "w")) == NULL)	//
		die("popen() failed.");	

	sprintf(buf, "%s.dm", fileid);
	fprintf(rpfp, "d3<-scan('%s')\n", buf);	
	fprintf(rpfp, "m3<-matrix(d3, %d, %d)\n", nsamples, nsamples);	
	fprintf(rpfp, "remove('d3')\n");	
	fprintf(rpfp, "ddd<-as.dist(m3)\n");	
	fprintf(rpfp, "remove('m3')\n");		
	fflush(rpfp);
	
	/* Call the real clustering function, either agglomerative or divisive */
	if (IS_DIANA(args->method)) {

		/* this has to be added to include the clustering library under R,
		 not required in Splus */

		fprintf(rpfp, "library(cluster)\n");		
		fprintf(rpfp, "h<-diana(ddd, diss = TRUE)\n");

	} else {
		
		fprintf(rpfp, "h<-hclust(ddd, method = \"%s\")\n", args->method);
	}
	
	/* Assign ID to structure so that we know which structure belongs
	 * to which cluster at the end
	 */
	
	fprintf(rpfp, "nnode<-numeric(%d)\n", nsamples);
	fprintf(rpfp, "nnode[1:%d]<-(1:%d)\n", nsamples, nsamples);		
	fflush(rpfp);

	/* Initialize array of saved cluster centroids */
	for (i=0; i<MAX_CLUSTERS; i++) {
		savedcc[i] = NULL;
	}
	
	/* going through a range of possible k and find the CH index
	 * value for each of them, then pick the k with the highest
	 * CH index.
	 */
	printf("Determining optimal number of clusters...\n");
	for (x=istart; x<=iend; x++) {
		within_clusters = 0.0;

		/* cutree cuts the clustering tree at a specified level
		 * and then determines how many clusters in that level
		 */
		fprintf(rpfp, "hh<-cutree(h, k=%d)\n", x);		

		/*
		 * Before we work on the clusters, we would first like to sort the
		 * output according to cluster size. We do all these in R.
		 */

		/* define temp variables */	
		fprintf(rpfp, "clen<-corder<-numeric(%d)\n", x);

		/* find cluster sizes */	
		fprintf(rpfp, "for (i in 1:%d) clen[i]=length(nnode[hh==i])\n", x);

		/* sort the cluster sizes in decreasing order and store cluster id
		 * according to this order
		 */	
		fprintf(rpfp, "corder<-order(clen, decreasing=TRUE)\n");

		/* now we reorder the cluster by assigning them different id */
		/* use MAX_CLUSTERS+i here to avoid overlapping new id */	
		fprintf(rpfp, "for (i in 1:%d) hh[hh==corder[i]]<-%d+i\n", x, MAX_CLUSTERS);

		/* done with the renumbering, we subtract MAX_CLUSTERS from */
		/* the new id to make id start with 1 again */
		fprintf(rpfp, "hh<-hh-%d\n", MAX_CLUSTERS);	
		fflush(rpfp);
		

		/* OK, done! we have rearranged the clusters according to their */
		/* sizes, i.e. largest = cluster 1, 2nd largest = cluster 2,... */

		/* create a new clustout object */
		thisco = new_clustout(x);

		/* initialize pointers to cluster centroids to NULL */
		for (i=0; i<x; i++) {
			ccentroid[i] = NULL;
		}

		for (i=1; i<=x; i++) {
			/* find number of elements in this cluster */

			/* ********* begin a substitute for expect v 2 ********* */	
			sprintf(buf, "%s.rd", fileid);		//base filename
			fprintf(rpfp, "zz <- file('%s.tmp', 'w', TRUE)\n", buf);			
			fprintf(rpfp, "sink(zz)\n");
			/* find number of elements in this cluster */
			fprintf(rpfp, "length(nnode[hh==%d])\n", i);	
			fprintf(rpfp, "sink()\n");	
			fprintf(rpfp, "close(zz)\n");
			fprintf(rpfp, "rm(zz)\n");					
			fprintf(rpfp, "file.rename('%s.tmp', '%s')\n", buf, buf);	
			fflush(rpfp);
			
			//wait for R to finish.	
			do {
				signal(SIGCHLD, SIG_IGN);
				fpFromR = fopen(buf, "r");
			} while (fpFromR == NULL);
			
			//dump file contents into array, mimicking expect behavior
			memset(rbuf, 0, ROUT_BUFF_SIZE-1);
			red = fread(rbuf, 1, ROUT_BUFF_SIZE-1, fpFromR);
			while (!feof(fpFromR)) {
				printf("another read is needed\n");
				fflush(stdout);
				//supplementary reads in case one wasn't enough.
				signal(SIGCHLD, SIG_IGN);
				red += fread(&(rbuf[red]), 1, ROUT_BUFF_SIZE-1-red, fpFromR);	
			}
			rbuf[red] = '\0';
			fclose(fpFromR);
			remove(buf);
			rbuf[strlen(rbuf)-1] = '\0';
			/* ********* end a substitute for expect v 2 ********* */
			
			ptrtmp = strtok(rbuf, " ");
			if (ptrtmp != NULL) {
				ptrtmp = strtok(NULL, " ");
				itmp = atoi(ptrtmp);
				if (itmp == 0)
					die("unknown output from length(nnode[hh==i])");
				set_cluster_size(thisco, i, itmp);
			} else
				die("unknown output from length(nnode[hh==i])");

			/* get all elements in cluster i */	
			j = 0;			
			/* ********* begin a substitute for expect v 2 ********* */		
			sprintf(buf, "%s.rd", fileid);		//base filename
			fprintf(rpfp, "zz <- file('%s.tmp', 'w', TRUE)\n", buf);	
			fprintf(rpfp, "sink(zz)\n");
			/* get all elements in cluster i */
			fprintf(rpfp, "nnode[hh==%d]\n", i);	
			fprintf(rpfp, "sink()\n");	
			fprintf(rpfp, "close(zz)\n");
			fprintf(rpfp, "rm(zz)\n");					
			fprintf(rpfp, "file.rename('%s.tmp', '%s')\n", buf, buf);	
			fflush(rpfp);
			
			//wait for R to finish.	
			do {
				signal(SIGCHLD, SIG_IGN);
				fpFromR = fopen(buf, "r");
			} while (fpFromR == NULL);
			
			//dump file contents into array, mimicking expect behavior
			memset(rbuf, 0, ROUT_BUFF_SIZE-1);
			red = fread(rbuf, 1, ROUT_BUFF_SIZE-1, fpFromR);
			while (!feof(fpFromR)) {
				printf("another read is needed\n");
				fflush(stdout);
				//supplementary reads in case one wasn't enough.
				signal(SIGCHLD, SIG_IGN);
				red += fread(&(rbuf[red]), 1, ROUT_BUFF_SIZE-1-red, fpFromR);
			}
			rbuf[red] = '\0';
			fclose(fpFromR);
			remove(buf);
			rbuf[strlen(rbuf)-1] = '\0';
			/* ********* end a substitute for expect v 2 ********* */
			
			ptrtmp = strtok(rbuf, " ");
			while (ptrtmp != NULL) {
				if (ptrtmp[0] >= '0' && ptrtmp[0] <= '9') {
					itmp = atoi(ptrtmp);
					if (itmp == 0)
						die("unknown output from nnode[hh==i]");
					add_member_to_cluster(sample, itmp, thisco, i);
				}
				ptrtmp = strtok(NULL, " ");
			}

			/* compute cluster centroid below */

			/* reset base pair frequency count vector */
			for (j=0; j<vsize; j++)
				bpcount[j] = 0;
		
			/* First compute the base pair frequency matrix */
			compute_bpcount(thisco->cmembers[i-1].members,
					thisco->cmembers[i-1].csize, bpcount, seqlen);
			
			/* Then we determine the ensemble centroid by looking at the bpcount matrix */
			ccentroid[i-1] = compute_centroid(bpcount, seqlen,
					thisco->cmembers[i-1].csize);

			/* find the sum of squared distances between the cluster centroid
			 and every member structure in this cluster */
			for (j=0; j<thisco->cmembers[i-1].csize; j++)
				within_clusters += find_bpdist(ccentroid[i-1],
						thisco->cmembers[i-1].members[j]);

		}

		/* Now compute between-clusters distances */
		between_clusters = 0.0;
		for (i=1; i<=x; i++)
			between_clusters += thisco->cmembers[i-1].csize * find_bpdist(
					ccentroid[i-1], ecentroid);

		if (x != 1 && within_clusters != 0.0)
			ch_index = between_clusters * (nsamples-x) / (x-1)
					/ within_clusters;
		else if (within_clusters == 0.0) {
			/*
			 * the sum of within-group distances is zero!
			 * meaning that we have got different clusters with each having
			 * identical structures. we can stop here as this
			 * should be the optimal clustering we can have.
			 * Note that this does NOT handle the case where
			 * we have all identical structures in the whole
			 * sample, cuz for that the optimal clustering is
			 * one cluster which is not within the range of
			 * this loop.
			 */
			ch_index = 0.0;
			optimal_k = x;
			optimal_ch = ch_index;

			/*
			 * if best cluster output object is saved earlier, free it before
			 * assigning it to a new object to avoid memory leak
			 */
			if (bestco != NULL)
				clean_clustout(bestco);
			bestco = thisco;

			/*
			 * save cluster centroids too! but remember to clean the old
			 * ones pointed to by savedcc first
			 */
			for (i=0; i<x; i++) {
				if (savedcc[i] != NULL)
					clean_structure(savedcc[i]);
				savedcc[i] = ccentroid[i];
			}

			printf("%2d %8.2f\n", x, ch_index);
			break;

		} else
			ch_index = -SCLASS_INFINITY;

		printf("%2d %8.2f\n", x, ch_index);

		if (ch_index > optimal_ch) {
			/* we just found a better result! save it */
			optimal_k = x;
			optimal_ch = ch_index;

			/*
			 * if best cluster output object is saved earlier, free it before
			 * assigning it to a new object to avoid memory leak
			 */
			if (bestco != NULL)
				clean_clustout(bestco);
			bestco = thisco;

			/*
			 * save cluster centroids too! but remember to clean the old
			 * ones pointed to by savedcc first
			 */
			for (i=0; i<x; i++) {
				if (savedcc[i] != NULL)
					clean_structure(savedcc[i]);
				savedcc[i] = ccentroid[i];
			}

		} else {
			/* this round of output is not as good as the best so far, */
			/* so clean the output */

			clean_clustout(thisco);

			/* clean cluster centroid structures also */
			for (i=0; i<x; i++)
				if (ccentroid[i] != NULL)
					clean_structure(ccentroid[i]);
		}

	}
	
	/* start cleaning up R */
	/* clean up expect substitute v 2 */
	fprintf(rpfp, "remove('nnode', 'hh', 'h', 'ddd')\n");
	fprintf(rpfp, "q()\n");		
	fflush(rpfp);
	pclose(rpfp);

	printf("\n\n");
	printf("Sequence length            = %d\n", seqlen);
	printf("Clustering method          = %s\n", args->method);
	printf("Optimal number of clusters = %d\n", optimal_k);

	min_fe_struct = (int *) malloc(sizeof(int) * optimal_k);
	if (min_fe_struct == NULL)
		die("unable to allocate memory");

	mfe_cc_closest_id = 0;
	mfe_cc_closest_dist = SCLASS_INFINITY;

	printf("\n");
	for (i=1; i<=optimal_k; i++) {
		printf("Cluster                 : %d\n", i);

		/* allocate memory for distances among all elements in this cluster */
		rsize = bestco->cmembers[i-1].csize * (bestco->cmembers[i-1].csize-1)
				/ 2;

		/* calculate max,min,avg distances within each cluster */
		max_dist = 0;
		avg_dist = 0;
		min_dist = SCLASS_INFINITY;

		/* also determine the mfe structure in this cluster in the same loop */
		min_fe = (float) SCLASS_INFINITY;
		min_fe_pos = 0;

		/* find distances between every pair of members in a cluster */
		for (j=0; j<bestco->cmembers[i-1].csize; j++) {
			for (k=j+1; k<bestco->cmembers[i-1].csize; k++) {
				if (dist[bestco->cmembers[i-1].sid[j]-1][bestco->cmembers[i-1].sid[k]-1]
						> max_dist)
					max_dist
							= dist[bestco->cmembers[i-1].sid[j]-1][bestco->cmembers[i-1].sid[k]-1];
				avg_dist
						+= dist[bestco->cmembers[i-1].sid[j]-1][bestco->cmembers[i-1].sid[k]-1];

				if (dist[bestco->cmembers[i-1].sid[j]-1][bestco->cmembers[i-1].sid[k]-1]
						< min_dist)
					min_dist
							= dist[bestco->cmembers[i-1].sid[j]-1][bestco->cmembers[i-1].sid[k]-1];
			}

			/* find minimum free energy structure in this cluster */
			if (sample_fe[bestco->cmembers[i-1].sid[j]-1] < min_fe) {
				min_fe = sample_fe[bestco->cmembers[i-1].sid[j]-1];
				min_fe_pos = bestco->cmembers[i-1].sid[j];
			}
		}

		min_fe_struct[i-1] = min_fe_pos;

		if (rsize != 0)
			avg_dist /= (float) rsize;
		if (min_dist == SCLASS_INFINITY)
			min_dist = 0;

		/* calculate standard deviation of distances in this cluster */
		std_dist = 0;
		for (j=0; j<bestco->cmembers[i-1].csize; j++)
			for (k=j+1; k<bestco->cmembers[i-1].csize; k++) {
				std_dist
						+= (float) pow(
								(dist[bestco->cmembers[i-1].sid[j]-1][bestco->cmembers[i-1].sid[k]-1]
										- avg_dist), 2.0);
			}
		if (rsize != 0)
			std_dist /= (float) rsize;
		std_dist = (float) sqrt((double) std_dist);

		printf("Maximum Distance        : %.0f\n", max_dist);
		printf("Minimum Distance        : %.0f\n", min_dist);
		printf("Average Distance        : %.2f\n", avg_dist);
		printf("Standard Deviation      : %.2f\n", std_dist);
		if (avg_dist != 0.0)
			printf("Coefficient of Variance : %.2f\n", std_dist/avg_dist);
		else
			printf("Coefficient of Variance : %.2f\n", 0.0);

		myprob = bestco->cmembers[i-1].csize / ((float) nsamples);
		printf("Probability             : %d/%d = %.3f\n",
				bestco->cmembers[i-1].csize, nsamples, myprob);

		if (myprob > dominant_prob) {
			dominant_prob = myprob;
			dominant_grp = i;
		}

		printf("Cluster MFE (Structure %d): %.2f\n", min_fe_pos, min_fe);
		printf("Elements:");
		for (j=0; j<bestco->cmembers[i-1].csize; j++)
			printf(" %d", bestco->cmembers[i-1].sid[j]);
		printf("\n\n");

		if (args->write_morefiles) {
			/* write cluster member list to c*.list */
			sprintf(buf, "%s/c%02d.list", args->ccdir, i);
			outfp = fopen(buf, "w");
			if (outfp == NULL)
				die("unable to create file for writing cluster member list");
			for (j=0; j<bestco->cmembers[i-1].csize; j++)
				fprintf(outfp, "%d ", bestco->cmembers[i-1].sid[j]);
			fprintf(outfp, "\n");
			fclose(outfp);

			/* write cluster member structures to c*.bp.out */
			sprintf(buf, "%s/c%02d.bp.out", args->ccdir, i);
			outfp = fopen(buf, "w");
			if (outfp == NULL)
				die("unable to create file for writing cluster bp.out");
			for (j=0; j<bestco->cmembers[i-1].csize; j++) {
				//        fprintf(outfp, "Structure %d\n", bestco->cmembers[i-1].sid[j]);
				fprintf(outfp, "Structure %d\n", j+1);
				print_structure(outfp, sample[bestco->cmembers[i-1].sid[j]-1]);
			}
			fclose(outfp);

			/* write cluster member energies to c*.fe.out */
			sprintf(buf, "%s/c%02d.fe.out", args->ccdir, i);
			outfp = fopen(buf, "w");
			if (outfp == NULL)
				die("unable to create file for writing cluster fe.out");
			for (j=0; j<bestco->cmembers[i-1].csize; j++)
				fprintf(outfp, "%6d %10.2f\n", j+1,
						sample_fe[bestco->cmembers[i-1].sid[j]-1]);
			fclose(outfp);
		}

		/* write cluster centroid to c*.ccentroid.bp */
		sprintf(buf, "%s/c%02d.ccentroid.bp", args->ccdir, i);
		outfp = fopen(buf, "w");
		if (outfp == NULL)
			die("unable to create file for writing cluster centroid");
		fprintf(outfp, "Structure 1\n");
		print_structure(outfp, savedcc[i-1]);
		fclose(outfp);

		/* determine free energy of cluster centroid */
		sprintf(
				cmd,
				"%s/findfe -p %s -f 2 -s %s %s/c%02d.ccentroid.bp | %s Free | %s '{print $4}'",
				SFOLDBIN, SFOLDPAR, args->seqfile, args->ccdir, i, PATH_GREP,
				PATH_AWK);
		if ((cmdptr=popen(cmd, "r")) == NULL)
			die("popen() failed.");
		if (!fgets(buf, MAX_BUFFER-1, cmdptr))
      die("cmd produced no output");
		ftmp = atof(buf);
		pclose(cmdptr);

		/* write cluster centroid in GCG connect format */
		sprintf(buf, "%s/c%02d.ccentroid.ct", args->ccdir, i);
		sprintf(cmd, "Centroid of Cluster %d", i);
		print_structure_ct(buf, cmd, savedcc[i-1], ftmp, seqlen, seq);

		if (MFE_DEFINED(args->gcgfile)) {
			/* 
			 * the following section is new:
			 * we are now trying to determine in which cluster the MFE should be
			 * located. We do this by first looking for the closest cluster
			 * centroid to the MFE structure, which is what we are doing below.
			 */
			itmp = find_bpdist(savedcc[i-1], mfest);
			if (itmp < mfe_cc_closest_dist) {
				mfe_cc_closest_dist = itmp;
				mfe_cc_closest_id = i;
			}
		}

	}

	if (MFE_DEFINED(args->gcgfile)) {
		/*
		 * ok, now we know which is the closest cluster centroid to the
		 * MFE structure. We then compute the maximum BP distance from
		 * this centroid to all cluster members. We will determine if
		 * the MFE structure is in this cluster by comparing this max.
		 * value and the distance between MFE and this centroid.
		 */
		cradius = 0;
		for (j=0; j<bestco->cmembers[mfe_cc_closest_id-1].csize; j++) {
			/* find maximum BP distance between a cluster member and the cluster centroid */
			itmp = find_bpdist(savedcc[mfe_cc_closest_id-1],
					bestco->cmembers[mfe_cc_closest_id-1].members[j]);
			if (itmp > cradius)
				cradius = itmp;
		}

		if (mfe_cc_closest_dist <= cradius)
			mfold_mfe_grp = mfe_cc_closest_id;
		else
			mfold_mfe_grp = 0;
	}

	printf("\n");
	printf("\n");

#ifdef VERBOSE_OUTPUT
	/* compute distances between min. free energy structures of all clusters */
	printf("Distance Matrix between All Cluster-level MFE Structures\n");
	for (i=0; i<optimal_k; i++) {
		for (j=0; j<optimal_k; j++)
		printf("%d ", dist[min_fe_struct[i]-1][min_fe_struct[j]-1]);
		printf("\n");
	}
	printf("\n");

	/* compute percentage matrix of base pairs in structure i
	 not shared by structure j */
	printf("Percentage of Base Pairs in Cluster i MFE Structure Not Shared by Cluster j MFE Structure (Pij)\n");
	printf("Format: (Pij, Pji) where i is the row ID and j is the column ID\n");
	for (i=0; i<optimal_k; i++) {
		for (j=0; j<optimal_k; j++)
		printf("(%.2f,%.2f) ", pdiff[min_fe_struct[i]-1][min_fe_struct[j]-1],
				pdiff[min_fe_struct[j]-1][min_fe_struct[i]-1]);
		printf("\n");
	}
	printf("\n");
#endif

	/* compute maximum/minimum/average distances between clusters */
	maxd_matrix = (int **) malloc(sizeof(int *) * optimal_k);
	if (maxd_matrix == NULL)
		die("unable to allocate memory");
	for (i=0; i<optimal_k; i++) {
		maxd_matrix[i] = (int *) calloc(sizeof(int), optimal_k);
		if (maxd_matrix[i] == NULL)
			die("unable to allocate memory");
	}

	mind_matrix = (int **) malloc(sizeof(int *) * optimal_k);
	if (mind_matrix == NULL)
		die("unable to allocate memory");
	for (i=0; i<optimal_k; i++) {
		mind_matrix[i] = (int *) calloc(sizeof(int), optimal_k);
		if (mind_matrix[i] == NULL)
			die("unable to allocate memory");
	}

	avgd_matrix = (float **) malloc(sizeof(float *) * optimal_k);
	if (avgd_matrix == NULL)
		die("unable to allocate memory");
	for (i=0; i<optimal_k; i++) {
		avgd_matrix[i] = (float *) calloc(sizeof(float), optimal_k);
		if (avgd_matrix[i] == NULL)
			die("unable to allocate memory");
	}

	for (i=0; i<optimal_k; i++)
		for (j=i+1; j<optimal_k; j++)
			mind_matrix[i][j] = SCLASS_INFINITY;

	for (i=0; i<optimal_k; i++)
		for (j=i+1; j<optimal_k; j++) {
			for (k=0; k<bestco->cmembers[i].csize; k++)
				for (x=0; x<bestco->cmembers[j].csize; x++) {
					avgd_matrix[i][j]
							+= dist[bestco->cmembers[i].sid[k]-1][bestco->cmembers[j].sid[x]-1];

					if (dist[bestco->cmembers[i].sid[k]-1][bestco->cmembers[j].sid[x]-1]
							> maxd_matrix[i][j])
						maxd_matrix[i][j]
								= dist[bestco->cmembers[i].sid[k]-1][bestco->cmembers[j].sid[x]-1];

					if (dist[bestco->cmembers[i].sid[k]-1][bestco->cmembers[j].sid[x]-1]
							< mind_matrix[i][j])
						mind_matrix[i][j]
								= dist[bestco->cmembers[i].sid[k]-1][bestco->cmembers[j].sid[x]-1];
				}

			avgd_matrix[i][j] /= (bestco->cmembers[i].csize
					* bestco->cmembers[j].csize);
			avgd_matrix[j][i] = avgd_matrix[i][j];
			maxd_matrix[j][i] = maxd_matrix[i][j];
			mind_matrix[j][i] = mind_matrix[i][j];
		}

	printf("Minimum Distance Matrix between Clusters\n");
	for (i=0; i<optimal_k; i++) {
		for (j=0; j<optimal_k; j++)
			printf("%d ", mind_matrix[i][j]);
		printf("\n");
	}
	printf("\n");

	printf("Maximum Distance Matrix between Clusters\n");
	for (i=0; i<optimal_k; i++) {
		for (j=0; j<optimal_k; j++)
			printf("%d ", maxd_matrix[i][j]);
		printf("\n");
	}
	printf("\n");

	printf("Average Distance Matrix between Clusters\n");
	for (i=0; i<optimal_k; i++) {
		for (j=0; j<optimal_k; j++)
			printf("%.2f ", avgd_matrix[i][j]);
		printf("\n");
	}
	printf("\n");

	for (i=0; i<optimal_k; i++)
		free(avgd_matrix[i]);
	free(avgd_matrix);

	for (i=0; i<optimal_k; i++)
		free(mind_matrix[i]);
	free(mind_matrix);

	for (i=0; i<optimal_k; i++)
		free(maxd_matrix[i]);
	free(maxd_matrix);

	/* compute distances between cluster centroids */
	printf("Distance matrix between cluster centroids\n");
	for (i=0; i<optimal_k; i++) {
		for (j=0; j<optimal_k; j++)
			printf("%d ", find_bpdist(savedcc[i], savedcc[j]));
		printf("\n");
	}
	printf("\n");

	printf("Dominant cluster = %d (with probability %.3f)\n", dominant_grp,
			dominant_prob);

	if (MFE_DEFINED(args->gcgfile)) {
		printf("mfold optimal structure appears in cluster %d\n", mfold_mfe_grp);
		printf("Boltzmann probability of mfold optimal structure = %s",
				mfold_mfe_bprob);
	}
	printf("\nCH index = %.2f\n", optimal_ch);
	printf("\n");

	free(min_fe_struct);

	free(sample_fe);
	free(seq);

	cleanup();

	return 0;
}

/* Subroutines */

void calculate_distmatrix(int n) {
	int i;

	/* allocate memory and initialize array to store distances */
	dist = (int **) malloc(sizeof(int *) * nsamples);
	if (dist == NULL)
		die("unable to allocate memory");

	for (i=0; i<nsamples; i++) {
		dist[i] = (int *) malloc(sizeof(int) * nsamples);
		if (dist[i] == NULL)
			die("unable to allocate memory");
	}
	for (i=0; i<nsamples; i++)
		dist[i][i] = 0;

#ifdef VERBOSE_OUTPUT
	/* allocate memory and initialize array to store percentage differences */
	pdiff = (float **) malloc(sizeof(float *) * nsamples);
	if (pdiff == NULL)
	die("unable to allocate memory");
	for (i=0; i<nsamples; i++) {
		pdiff[i] = (float *) malloc(sizeof(float) * nsamples);
		if (pdiff[i] == NULL)
		die("unable to allocate memory");
	}
	for (i=0; i<nsamples; i++)
	pdiff[i][i] = 0.0;
#endif

	find_distmatrix(n, nsamples, args->bpfile, dist, pdiff);
}

void cleanup(void) {
	int i;
	char cmd[MAX_BUFFER];

	if (fileid) {
		sprintf(cmd, "rm -f %s.dv", fileid);
    // I cannot check exit status of system because it is different on solaris and linux :(
    system(cmd);
		sprintf(cmd, "rm -f %s.dm", fileid);
    system(cmd);
		sprintf(cmd, "rm -f %s.pd", fileid);
    system(cmd);
		sprintf(cmd, "rm -f %s.gcg.*", fileid);
    system(cmd);
	}

	if (args) {
		if (args->bpfile)
			free(args->bpfile);
		if (args->fefile)
			free(args->fefile);
		if (args->gcgfile)
			free(args->gcgfile);
		if (args->probfile)
			free(args->probfile);
		if (args->seqfile)
			free(args->seqfile);
		if (args->method)
			free(args->method);
		if (args->ecdir)
			free(args->ecdir);
		if (args->ccdir)
			free(args->ccdir);

		free(args);
	}

	if (dist) {
		for (i=0; i<nsamples; i++)
			if (dist[i])
				free(dist[i]);
		free(dist);
	}
	if (pdiff) {
		for (i=0; i<nsamples; i++)
			if (pdiff[i])
				free(pdiff[i]);
		free(pdiff);
	}
}


void init_env(char *pn) {
	char *m;
	char path[MAX_PATHSIZE];
	int i;

	if ((m=strrchr(pn, '/')) != NULL) {
		for (i=0; i<(strlen(pn)-strlen(m)); i++)
			path[i] = pn[i];
		path[i++] = '/';
		path[i] = '\0';
	}

}

void loadenv(void) {
	SFOLDBIN = getenv("SFOLDBIN");
	if (!SFOLDBIN)
		die("unable to load environment variable 'SFOLDBIN'.");

	SFOLDPAR = getenv("SFOLDPAR");
	if (!SFOLDPAR)
		die("unable to load environment variable 'SFOLDPAR'.");

	BPROBEXE = getenv("BPROBEXE");
	if (!BPROBEXE)
		die("unable to load environment variable 'BPROBEXE'.");

	PATH_AWK = getenv("PATH_AWK");
	if (!PATH_AWK)
		die("unable to load environment variable 'PATH_AWK'.");

	PATH_GREP = getenv("PATH_GREP");
	if (!PATH_GREP)
		die("unable to load environment variable 'PATH_GREP'.");

	PATH_R = getenv("PATH_R");
	if (!PATH_R)
		die("unable to load environment variable 'PATH_R'.");
}
/*
int my_expect(int h) {
	char cp_re[] = "> $";
	int dummy;

	dummy = exp_expectl(h, exp_regexp, cp_re, 1, exp_end);
	if (dummy == EXP_EOF)
		fprintf(stderr, " Error: EOF on expect.\n");
	else if (dummy == EXP_TIMEOUT)
		fprintf(stderr, " Error: timeout on expect.\n");

	return dummy;
}
*/
int read_fe(char *fefile, int nsamples, float *fe) {
	FILE *fp;
	int i, count = 0;
	float f;

	if ((fp=fopen(fefile, "r")) == NULL)
		die("Unable to open free energy file");
	if (fe == NULL)
		die("null fe structure passed to read_fe()");

	while (fscanf(fp, "%d %f", &i, &f) > 0) {
		if (count < nsamples)
			fe[count] = f;
		count++;
	}
	fclose(fp);
	return count;
}

struct ProgArgs *setArgs(int argc, char *argv[]) {
	struct ProgArgs *a = NULL;
	int i, itmp;

	a = (struct ProgArgs *) malloc(sizeof(struct ProgArgs));
	if (a == NULL) {
		fprintf(stderr,
				" Error: failed to allocate memory for program arguments\n");
		usage(argv[0]);
		return NULL;
	}

	/* Initialize structure elements */
	a->bpfile = NULL;
	a->fefile = NULL;
	a->gcgfile = NULL;
	a->probfile = NULL;
	a->seqfile = NULL;
	a->method = NULL;
	a->nclusters = 0;
	a->write_morefiles = DEF_WRITE_MOREFILES;
	a->ecdir = NULL;
	a->ccdir = NULL;

	/* Do the argument matching here... */
	if (argc < 2) {
		usage(argv[0]);
		return NULL;
	}

	for (i=1; i<argc; i++)
		if (strcmp(argv[i], "-h") == 0) {
			usage(argv[0]);
			return NULL;
		}

	i = 1;
	while (i < argc) {
		if (argv[i][0] == '-') {
			/* this is an option field */
			if (i >= argc-1) {
				fprintf(stderr, " Error: argument to '%s' is missing\n",
						argv[i]);
				return NULL;
			}

			if (strcmp(argv[i]+1, "b") == 0) {
				a->bpfile = (char *) malloc(sizeof(char)
						* (strlen(argv[++i])+1));
				strcpy(a->bpfile, argv[i]);

			} else if (strcmp(argv[i]+1, "c") == 0) {
				a->ccdir
						= (char *) malloc(sizeof(char) * (strlen(argv[++i])+1));
				strcpy(a->ccdir, argv[i]);

			} else if (strcmp(argv[i]+1, "e") == 0) {
				a->ecdir
						= (char *) malloc(sizeof(char) * (strlen(argv[++i])+1));
				strcpy(a->ecdir, argv[i]);

			} else if (strcmp(argv[i]+1, "f") == 0) {
				a->fefile = (char *) malloc(sizeof(char)
						* (strlen(argv[++i])+1));
				strcpy(a->fefile, argv[i]);

				/*
				 } else if (strcmp(argv[i]+1,"d") == 0) {
				 i++;

				 if (strcmp(argv[i],"average")!=0 && strcmp(argv[i],"complete")!=0
				 && strcmp(argv[i],"single")!=0 && strcmp(argv[i],"ward")!=0
				 && strcmp(argv[i],"mcquitty")!=0 && strcmp(argv[i],"median")!=0
				 && strcmp(argv[i],"centroid")!=0 && strcmp(argv[i],"divisive")!=0) {
				 fprintf(stderr," Error: unknown clustering method '%s'\n", argv[i]);
				 return NULL;
				 }

				 a->method = (char *) malloc(sizeof(char) * (strlen(argv[i])+1));
				 strcpy(a->method, argv[i]);
				 */

			} else if (strcmp(argv[i]+1, "m") == 0) {
				a->gcgfile = (char *) malloc(sizeof(char) * (strlen(argv[++i])
						+1));
				strcpy(a->gcgfile, argv[i]);

			} else if (strcmp(argv[i]+1, "p") == 0) {
				a->probfile = (char *) malloc(sizeof(char) * (strlen(argv[++i])
						+1));
				strcpy(a->probfile, argv[i]);

			} else if (strcmp(argv[i]+1, "s") == 0) {
				a->seqfile = (char *) malloc(sizeof(char) * (strlen(argv[++i])
						+1));
				strcpy(a->seqfile, argv[i]);

			} else if (strcmp(argv[i]+1, "k") == 0) {
				a->nclusters = atoi(argv[++i]);

			} else if (strcmp(argv[i]+1, "w") == 0) {
				itmp = atoi(argv[++i]);
				if (itmp == 0 || itmp == 1)
					a->write_morefiles = itmp;
				else {
					fprintf(stderr,
							" Error: invalid value passed to the '-w' option\n");
					return NULL;
				}

			} else {
				fprintf(stderr, " Error: unknown argument '%s'\n", argv[i]);
				return NULL;
			}

		} else {
			fprintf(stderr, " Error: unknown argument '%s'\n", argv[i]);
			return NULL;
		}

		i++;
	}

	if (!a->seqfile) {
		fprintf(stderr, " Error: no sequence file\n");
		return NULL;
	}
	if (a->bpfile == NULL) {
		a->bpfile = (char *) malloc(sizeof(char) * (strlen(DEF_BPFILE)+1));
		strcpy(a->bpfile, DEF_BPFILE);
	}
	if (a->fefile == NULL) {
		a->fefile = (char *) malloc(sizeof(char) * (strlen(DEF_FEFILE)+1));
		strcpy(a->fefile, DEF_FEFILE);
	}
	if (a->probfile == NULL) {
		a->probfile = (char *) malloc(sizeof(char) * (strlen(DEF_PROBFILE)+1));
		strcpy(a->probfile, DEF_PROBFILE);
	}
	if (a->method == NULL) {
		a->method = (char *) malloc(sizeof(char) * (strlen(DEF_METHOD)+1));
		strcpy(a->method, DEF_METHOD);
	}
	if (a->ecdir == NULL) {
		a->ecdir = (char *) malloc(sizeof(char) * (strlen(DEF_ECDIR)+1));
		strcpy(a->ecdir, DEF_ECDIR);
	}
	if (a->ccdir == NULL) {
		a->ccdir = (char *) malloc(sizeof(char) * (strlen(DEF_CCDIR)+1));
		strcpy(a->ccdir, DEF_CCDIR);
	}

	/* now check the existence of input files */
	if (access(a->seqfile, F_OK) != 0) {
		/* it does not exist! */
		fprintf(stderr, " Error: unable to locate file '%s'!\n", a->seqfile);
		return NULL;
	}
	if (access(a->bpfile, F_OK) != 0) {
		/* it does not exist! */
		fprintf(stderr, " Error: unable to locate file '%s'!\n", a->bpfile);
		return NULL;
	}
	if (access(a->fefile, F_OK) != 0) {
		/* it does not exist! */
		fprintf(stderr, " Error: unable to locate file '%s'!\n", a->fefile);
		return NULL;
	}
	if (access(a->probfile, F_OK) != 0) {
		/* it does not exist! */
		fprintf(stderr, " Error: unable to locate file '%s'!\n", a->probfile);
		return NULL;
	}
	if (MFE_DEFINED(a->gcgfile)) {
		if (access(a->gcgfile, F_OK) != 0) {
			/* it does not exist! */
			fprintf(stderr, " Error: unable to locate file '%s'!\n", a->gcgfile);
			return NULL;
		}
	}

	/* check the existence of output directories */
	if (access(a->ecdir, F_OK) != 0) {
		/* output directory does not exist! */
		fprintf(stderr, " Error: output directory '%s' does not exist!\n",
				a->ecdir);
		return NULL;
	}
	if (access(a->ccdir, F_OK) != 0) {
		/* output directory does not exist! */
		fprintf(stderr, " Error: output directory '%s' does not exist!\n",
				a->ccdir);
		return NULL;
	}

	return a;
}

void sigint(int sig) {
	cleanup();
	exit(-1);
}

void usage(char *pn) {
	printf("Usage: %s [options]... -s sequence_file\n", pn);
	printf("Options:\n");
	printf("  -b <string>         Base pair file from Sfold [default=%s]\n",
			DEF_BPFILE);
	printf("  -c <string>         Directory to store output files from clustering\n");
	printf("                      [default=%s]\n", DEF_CCDIR);
	//  printf("  -d <string>         Hierarchical clustering method (average/complete/single/\n");
	//  printf("                      ward/mcquitty/median/centroid/divisive)\n");
	//  printf("                      [default=%s]\n", DEF_METHOD);
	printf(
			"  -e <string>         Directory to store ensemble centroid [default=%s]\n", 
			DEF_ECDIR);
	printf("  -f <string>         Free energy file from Sfold [default=%s]\n",
			DEF_FEFILE);
	printf("  -h                  Display this information\n");
	printf("  -k <integer>        Optimal number of clusters [default=auto]\n");
	printf("  -m <string>         MFE structure in GCG connect format (optional)\n");
	printf("  -p <string>         bprob.out from Sfold for Boltzmann Prob.\n");
	printf("                      [default=%s]\n", DEF_PROBFILE);
	printf("  -s <string>         Sequence file in FASTA format (required)\n");
	printf("  -w <0 or 1>         Provide detailed clustering results in additional\n");
	printf("                      output files [default=%d]\n",
			DEF_WRITE_MOREFILES);
	printf("\n");
	return;
}
