#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "param.h"

#define DEF_PARDIR          "../param/"

#ifdef _CRAY
#  include <fortran.h>
#  define dangle3           DANGLE3
#  define dangle5           DANGLE5
#else
#  if !defined(_AIX) && !defined(__hpux)
#    define dangle3         dangle3_
#    define dangle5         dangle5_
#  endif
#  define _fcd          char *
#  define _cptofcd(a,b) (a)
#  define _fcdlen(a)    strlen(a)
#endif

struct ProgArgs {
  int dend;
  char base1;
  char base2;
  char base3;
  char *pardir;
};


/* function prototype */
double dangle3(int *base1, int *base2, int *base3, char *pardir, int *pardirlen);
double dangle5(int *base1, int *base2, int *base3, char *pardir, int *pardirlen);
struct ProgArgs *setArgs(int argc, char *argv[]);
void freeArgs(struct ProgArgs *args);
int seq2id(char *seq, int *id, int n);
void usage(char *pn);


/* Parse command line arguments in C and pass them to the fortran subroutine */
int main(int argc, char *argv[]) {
  struct ProgArgs *args;
  int n1, n2, n3;
  double energy = 0.0;
  int pardirlen=0;

  if ((args = setArgs(argc, argv)) == NULL) {
    usage(argv[0]);
    return -1;
  }

  /* check to see if the specified parameter directory and
     the required parameter files exist */
  if (verify_parfiles(args->pardir) < 0)
    return -2;
  pardirlen = strlen(args->pardir);

  /* convert nucleotides to base IDs according to (A,C,G,U)=(1,2,3,4) */
  seq2id(&(args->base1), &n1, 1);
  seq2id(&(args->base2), &n2, 1);
  seq2id(&(args->base3), &n3, 1);


  /* call the corresponding Fortran subroutine */
  if (args->dend == 3)
    energy = dangle3(&n1, &n2, &n3, args->pardir, &pardirlen);
  else if (args->dend == 5)
    energy = dangle5(&n1, &n2, &n3, args->pardir, &pardirlen);

  printf("%.1f\n", energy);

  freeArgs(args);

  return 0;
}


struct ProgArgs *setArgs(int argc, char *argv[]) {
  struct ProgArgs *args;
  int i;

  args = (struct ProgArgs *) malloc(sizeof(struct ProgArgs));
  if (args == NULL) {
    fprintf(stderr," Error: failed to allocate memory for program arguments\n");
    return NULL;
  }

  /* Initialize structure elements */
  args->dend = 0;
  args->base1 = ' ';
  args->base2 = ' ';
  args->base3 = ' ';
  args->pardir = NULL;

  /* Do the argument matching here... */
  if (argc < 2) {
    return NULL;
  }

  for (i=1; i<argc; i++)
    if (strcmp(argv[i], "-h") == 0)
      return NULL;

  i = 1;
  while (i < argc) {
    if (argv[i][0] == '-') {
      /* this is an option field */
      if (i >= argc-1) {
        fprintf(stderr," Error: argument to '%s' is missing\n", argv[i]);
        return NULL;
      }

      if (strcmp(argv[i]+1,"a") == 0) {
        args->base1 = argv[++i][0];
        /* convert to uppercase */
        if (args->base1 >= 'a' && args->base1 <= 'z')
          args->base1 -= 32;
        if (args->base1 == 'T')
          args->base1 = 'U';

      } else if (strcmp(argv[i]+1,"b") == 0) {
        args->base2 = argv[++i][0];
        /* convert to uppercase */
        if (args->base2 >= 'a' && args->base2 <= 'z')
          args->base2 -= 32;
        if (args->base2 == 'T')
          args->base2 = 'U';

      } else if (strcmp(argv[i]+1,"c") == 0) {
        args->base3 = argv[++i][0];
        /* convert to uppercase */
        if (args->base3 >= 'a' && args->base3 <= 'z')
          args->base3 -= 32;
        if (args->base3 == 'T')
          args->base3 = 'U';

      } else if (strcmp(argv[i]+1,"e") == 0) {
        args->dend = atoi(argv[++i]);

      } else if (strcmp(argv[i]+1,"p") == 0) {
        /* this specifies the directory from which parameter files
         * are to be read
         */
        i++;
        if (!args->pardir)
          args->pardir = strdup(argv[i]);
        else
          fprintf(stderr," Warning: ignoring duplicate parameter directory '%s'\n", argv[i]);

      } else {
        fprintf(stderr," Error: unknown argument '%s'\n", argv[i]);
        return NULL;
      }

    } else {
      fprintf(stderr," Error: unknown argument '%s'\n", argv[i]);
      return NULL;
    }

    i++;
  }

  if (args->dend != 3 && args->dend != 5) {
    fprintf(stderr, " Error: invalid dangling end defined.\n");
    return NULL;
  }

  if (args->base1 != 'A' && args->base1 != 'U' && args->base1 != 'C'
      && args->base1 != 'G') {
    fprintf(stderr, " Error: invalid nucleotide at position 1.\n");
    return NULL;
  }

  if (args->base2 != 'A' && args->base2 != 'U' && args->base2 != 'C'
      && args->base2 != 'G') {
    fprintf(stderr, " Error: invalid nucleotide at position 2.\n");
    return NULL;
  }

  if (args->base3 != 'A' && args->base3 != 'U' && args->base3 != 'C'
      && args->base3 != 'G') {
    fprintf(stderr, " Error: invalid nucleotide at position 3.\n");
    return NULL;
  }

  if (!args->pardir) {
    args->pardir = strdup(DEF_PARDIR);
  }

  return args;
}

void freeArgs(struct ProgArgs *args) {
  if (args) {
    if (args->pardir)
      free(args->pardir);

    free(args);
  }
}

/*
 * Convert input sequence to an array of base IDs based on
 * the the following scheme: (A,C,G,U)=(1,2,3,4)
 */
int seq2id(char *seq, int *id, int n) {
  int i;

  for (i=0; i<n; i++) {
    switch (seq[i]) {
      case 'A':
        id[i] = 1;
        break;
      case 'C':
        id[i] = 2;
        break;
      case 'G':
        id[i] = 3;
        break;
      case 'U':
        id[i] = 4;
        break;
      default:
        fprintf(stderr, " Error: internal error\n");
        return -1;
    }
  }

  return n;
}

void usage(char *pn) {
  printf("\n");
  printf("Usage: %s -e <int> -a <char> -b <char> -c <char> [-p <string>]\n", pn);
  printf("Options:\n");
  printf("  -a <char>        nucleotide at position 1 (see diagrams below)\n");
  printf("  -b <char>        nucleotide at position 2 (see diagrams below)\n");
  printf("  -c <char>        nucleotide at position 3 (see diagrams below)\n");
  printf("  -e <int>         5' or 3' dangling end [5 or 3]\n");
  printf("  -h               Display this information\n");
  printf("  -p <string>      Name of directory from which parameter files are read\n");
  printf("                   [default=%s]\n", DEF_PARDIR);
  printf("\n");
  printf("  Position IDs for 3' and 5' dangling ends\n");
  printf("        5' --> 3'           5' --> 3' \n");
  printf("           23                  2      \n");
  printf("           1                   13     \n");
  printf("        3' <-- 5'           3' <-- 5' \n");
  printf("\n");
  return;
}
