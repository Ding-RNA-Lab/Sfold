#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include "param.h"

#define DEF_FORMAT          1
#define DEF_PARDIR          "../param/"


#ifdef _CRAY
#  include <fortran.h>
#  define f77findfe         F77FINDFE
#else
#  if !defined(_AIX) && !defined(__hpux)
#    define f77findfe       f77findfe_
#  endif
#  define _fcd          char *
#  define _cptofcd(a,b) (a)
#  define _fcdlen(a)    strlen(a)
#endif

struct ProgArgs {
  int format;
  char *strfile;
  char *seqfile;
  char *pardir;
};


/* function prototype */
int check_fbp(int n, int *fbp);
void f77findfe(int *n, int *numseq, int *fbp, int *h5, int *h3, int *hnum,
  char *seq, double *eall, char *pardir, int *pardirlen);
FILE *file_open(char *p, char *m);
int fillvar_bp(struct ProgArgs *args, int n, char *s, int *fbp);
int fillvar_ct(struct ProgArgs *args, int n, char *s, int *fbp);
int fillvar_hx(struct ProgArgs *args, int n, char *s, int *fbp);
int getlen(struct ProgArgs *args);
int getctlen(char *fn);
int getseqlen(char *fn);
int readFASTA(char *fn, int n, char *s);
struct ProgArgs * setArgs(int argc, char *argv[]);
void freeArgs(struct ProgArgs *args);
void usage(char *pn);


/* Take command line arguments from C and pass them to the fortran subroutine */
int main(int argc, char *argv[]) {
  struct ProgArgs *args;
  int n, ret;
  int *numseq, *fbp, *h5, *h3, *hnum;
  double eall;
  char *seq;
  int i;
  int pardirlen=0;

  //intialize!
  eall = 0.0;
  
  if ((args = setArgs(argc, argv)) == NULL) {
    usage(argv[0]);
    return -1;
  }

  n = getlen(args);
  if (n <= 0)
    return -3;

  /* Now check to see if the specified parameter directory and
     the required parameter files exist */
  if (verify_parfiles(args->pardir) < 0)
    return -6;
  pardirlen = strlen(args->pardir);


  /* allocate space */
  numseq = (int *) calloc(((size_t) n), sizeof(int));
  fbp = (int *) calloc(((size_t) n), sizeof(int));
  h5 = (int *) calloc(((size_t) n), sizeof(int));
  h3 = (int *) calloc(((size_t) n), sizeof(int));
  hnum = (int *) calloc(((size_t) n), sizeof(int));
  if (numseq == NULL || fbp == NULL || h5 == NULL ||
      h3 == NULL || hnum == NULL) {
    fprintf(stderr,"Failed to allocate space for 1-d integer arrays\n");
    return -2;
  }
  
  //initialize numseq, fbp, h5, h3, hnum
  for (i=0;i<n;i++) {
	  numseq[i] = 0;
	  fbp[i] = 0;
	  h5[i] = 0;
	  h3[i] = 0;
	  hnum[i] = 0;
  }

  seq = (char *) calloc(((size_t) n), sizeof(char));
  if (seq == NULL) {
    fprintf(stderr,"Failed to allocate space for character arrays\n");
    return -2;
  }


  switch (args->format) {
    case 1:
      /* GCG connect format */
      ret = fillvar_ct(args, n, seq, fbp);
      break;
    case 2:
      /* BP format */
      ret = fillvar_bp(args, n, seq, fbp);
      break;
    case 3:
      /* Helix format */
      ret = fillvar_hx(args, n, seq, fbp);
      break;
    default:
      fprintf(stderr, "Unknown structure file format\n");
      return -1;
  }

  if (ret < 0)
    return -4;

  /* check correctness of fbp */
  if (check_fbp(n, fbp) < 0)
    return -5;

  /* print first 10 and last 10 nt if n >= 10;
     print the whole sequence if n < 10 */
  printf("\n");
  if (n >= 10) {
    for (i=0; i<10; i++)
      printf("%6d  %c\n", i+1, seq[i]);
    for (i=n-10; i<n; i++)
      printf("%6d  %c\n", i+1, seq[i]);
  } else {
    for (i=0; i<n; i++)
      printf("%6d  %c\n", i+1, seq[i]);
  }
  printf("\n");

  //2008-08-07 (Adam): Skip the findfe function if structure is open. (.bp files only)
  if (ret > 0) {
	  f77findfe(&n, numseq, fbp, h5, h3, hnum, seq, &eall, args->pardir, &pardirlen);
  }
  
  printf("Sequence length = %d\n", n);
  printf("Free energy     = %.2f\n", eall);
  printf("\n");

  freeArgs(args);

  return 0;
}

/*
 * Check the array fbp to make sure it has neither inconsistent base
 * pairs nor pseudoknots
 */
int check_fbp(int n, int *fbp) {
  int i, j;

  for (i=0; i<n; i++) {
    /* Check for invalid fbp value */
    if (fbp[i] < 0 || fbp[i] > n) {
      fprintf(stderr, "Invalid base pair (%d, %d)\n", i+1, fbp[i]);
      return -1;
    }

    /* check for consistent pairs */
    if (fbp[i] > 0 && fbp[i] <= n) {
      if (fbp[fbp[i]-1] != i+1) {
        fprintf(stderr, "Inconsistent base pair (%d, %d) and (%d, %d)\n",
          i+1, fbp[i], fbp[i], fbp[fbp[i]-1]);
        return -2;
      }

      /* check for pseudoknots */
      if ((i+1) < fbp[i])
        for (j=i+1; j<fbp[i]-1; j++)
          if ((fbp[j] < i+1 || fbp[j] > fbp[i]) && fbp[j] != 0) {
            fprintf(stderr, "Found pseudoknot (%d, %d) x (%d, %d)\n",
              i+1, fbp[i], j+1, fbp[j]);
            return -3;
          }
    }
  }

  return 0;
}


/*
 * A wrapper function for fopen to determine where we should read from.
 * If STDIN is the source of input, we can call fdopen instead of fopen
 */
FILE *file_open(char *p, char *m) {
  FILE *fp;

  if (strcasecmp(p, "STDIN") == 0) {
    /* we are reading from the standard input (0) */
    fp = fdopen(0, m);
  } else {
    /* do a normal file open */
    fp = fopen(p, m);
  }

  return fp;
}


/*
 * Fill sequence data and structure from bp file into arrays
 */
int fillvar_bp(struct ProgArgs *args, int n, char *s, int *fbp) {
  int count = 0;
  FILE *fp;
  char *ch, *tok;
  char buf[256];
  int i, j;
  //2008-08-07 (Adam): Add flag to for empty file, used to skip the findfe function if structure is open.
  int emptyFile = 1;	//default to empty, change if not empty
  
  count = readFASTA(args->seqfile, n, s);
  if (count != n) {
    fprintf(stderr, "Inconsistent sequence length\n");
    return -2;
  }

  if ((fp=file_open(args->strfile, "r")) == NULL) {
    fprintf(stderr, "Unable to read from file '%s'\n", args->strfile);
    return -1;
  }

  /*  data start here */
  do {
    i = j = 0;

    ch = fgets(buf, 256, fp);
    /* 1st column: position i */
    tok = strtok(ch, " ");
    if (tok != NULL)
      i = atoi(tok);
    /* 2nd column: position j */
    tok = strtok(NULL, " ");
    if (tok != NULL)
      j = atoi(tok);
    /* Check to see if it has the 3rd column; if so, possibly a different format */
    tok = strtok(NULL, " ");
    if (tok != NULL) {
      fprintf(stderr, "Structure file not in bp format\n");
      return -3;
    }

    if ( i>0 && i<=n && j>0 && j<=n && i!=j ) {
      fbp[i-1] = j;
      fbp[j-1] = i;
      //2008-08-07 (Adam): Add flag to for empty file, used to skip the findfe function if structure is open.
      emptyFile = 0;
    }

  } while (ch != NULL);

  fclose(fp);

  //2008-08-07 (Adam): Add flag to for empty file, used to skip the findfe function if structure is open.
  if (emptyFile == 1)
	  return 0;
  return count;
  
}

/*
 * Fill sequence data and structure from GCG connect file into arrays
 */
int fillvar_ct(struct ProgArgs *args, int n, char *s, int *fbp) {
  int count = 0;
  FILE *fp;
  char buf[256];
  char *ch, *tok;
  int i, j;
  char nuc;

  if ((fp=file_open(args->strfile, "r")) == NULL) {
    fprintf(stderr, "Unable to read from file '%s'\n", args->strfile);
    return -1;
  }

  /* sequence data start here */
  do {
    i = j = 0;
    nuc = ' ';

    ch = fgets(buf, 256, fp);
    /* 1st column: position i */
    tok = strtok(ch, " ");
    if (tok != NULL)
      i = atoi(tok);
    /* 2nd column: Sequence alphabet */
    tok = strtok(NULL, " ");
    if (tok != NULL)
      nuc = tok[0];
    /* Skip column 3 and 4 */
    tok = strtok(NULL, " ");
    tok = strtok(NULL, " ");
    /* 5th column: position j */
    tok = strtok(NULL, " ");
    if (tok != NULL)
      j = atoi(tok);

    if ( i>0 && i<=n && j>=0 && j<=n && i!=j &&
         (nuc=='A' || nuc=='T' || nuc=='C' || nuc=='G' || nuc=='U' || nuc=='N' ||
          nuc=='a' || nuc=='t' || nuc=='c' || nuc=='g' || nuc=='u' || nuc=='n') ) {
      fbp[i-1] = j;
      fbp[j-1] = i;
      nuc = toupper(nuc);
      if (nuc == 'T')
        nuc = 'U';
      s[count++] = nuc;
    }
  } while (ch != NULL && count < n);

  fclose(fp);

  if (count != n) {
    fprintf(stderr, "Inconsistent sequence length\n");
    return -2;
  }

  return count;
}

/*
 * Fill sequence data and structure from helix format file into arrays
 */
int fillvar_hx(struct ProgArgs *args, int n, char *s, int *fbp) {
  int count = 0;
  FILE *fp;
  char *ch, *tok;
  char buf[256];
  int i, j, k, x;

  count = readFASTA(args->seqfile, n, s);
  if (count != n) {
    fprintf(stderr, "Inconsistent sequence length\n");
    return -2;
  }

  if ((fp=file_open(args->strfile, "r")) == NULL) {
    fprintf(stderr, "Unable to read from file '%s'\n", args->strfile);
    return -1;
  }

  /*  data start here */
  do {
    i = j = k = 0;

    ch = fgets(buf, 256, fp);
    /* 1st column: position i */
    tok = strtok(ch, " ");
    if (tok != NULL)
      i = atoi(tok);
    /* 2nd column: position j */
    tok = strtok(NULL, " ");
    if (tok != NULL)
      j = atoi(tok);
    /* 3rd column: count k */
    tok = strtok(NULL, " ");
    if (tok != NULL)
      k = atoi(tok);
    if (i!=0 && j!=0 && k==0) {
      fprintf(stderr, "Structure file not in helix format\n");
      return -3;
    }

    if ( i>0 && i<=n && j>0 && j<=n && k>0 && k<=n && i!=j && k<=(n-3)/2 ) {
      for (x=0; x<k; x++) {
        fbp[i+x-1] = j-x;
        fbp[j-x-1] = i+x;
      }
    }

  } while (ch != NULL);

  fclose(fp);

  return count;
}

/*
 * Find the sequence length
 */
int getlen(struct ProgArgs *args) {
  int count = 0;

  switch (args->format) {
    case 1:
      /* GCG connect format */
      count = getctlen(args->strfile);
      break;
    case 2:
      /* BP format */
    case 3:
      /* Helix format */
      count = getseqlen(args->seqfile);
      break;
    default:
      fprintf(stderr, "Unknown structure file format\n");
      return -1;
  }

  return count;
}

/*
 * Parse the GCG connect file and find the sequence length
 */
int getctlen(char *fn) {
  int count = 0, i, j;
  FILE *fp;
  char buf[256];
  char *ch, *tok;
  char nuc;

  if ((fp=file_open(fn, "r")) == NULL) {
    fprintf(stderr, "Unable to read from file '%s'\n", fn);
    return -1;
  }

  /* sequence data start here */
  do {
    i = j = 0;
    nuc = ' ';

    ch = fgets(buf, 256, fp);
    /* 1st column: position i */
    tok = strtok(ch, " ");
    if (tok != NULL)
      i = atoi(tok);
    /* 2nd column: Sequence alphabet */
    tok = strtok(NULL, " ");
    if (tok != NULL)
      nuc = tok[0];
    /* Skip column 3 and 4 */
    tok = strtok(NULL, " ");
    tok = strtok(NULL, " ");
    /* 5th column: position j */
    tok = strtok(NULL, " ");
    if (tok != NULL)
      j = atoi(tok);

    if ( i>0 && j>=0 && i!=j &&
         (nuc=='A' || nuc=='T' || nuc=='C' || nuc=='G' || nuc=='U' || nuc=='N' ||
          nuc=='a' || nuc=='t' || nuc=='c' || nuc=='g' || nuc=='u' || nuc=='n') ) {
      count++;
    }
  } while (ch != NULL);

  fclose(fp);

  if (count == 0)
    fprintf(stderr, "Sequence is of zero length\n");

  return count;
}

/*
 * Parse the input sequence file (in FASTA format) to find the sequence length
 */
int getseqlen(char *fn) {
  int count = 0, ch;
  FILE *fp;

  if ((fp=fopen(fn, "r")) == NULL) {
    fprintf(stderr, "Unable to read from file '%s'\n", fn);
    return -1;
  }

  ch = fgetc(fp);
  if (ch != '>') {
    fprintf(stderr, "Invalid FASTA file format\n");
    return -2;
  }

  /* skip sequence header */
  do {
    ch = fgetc(fp);
  } while (ch != EOF && ch != '\n');

  /* sequence data start here */
  while (ch != EOF) {
    ch = fgetc(fp);
    if (ch == 'A' || ch == 'T' || ch == 'C' || ch == 'G' || ch == 'U' || ch == 'N' ||
        ch == 'a' || ch == 't' || ch == 'c' || ch == 'g' || ch == 'u' || ch == 'n')
      count++;
  }

  fclose(fp);

  if (count == 0)
    fprintf(stderr, "Sequence is of zero length\n");

  return count;
}

/*
 * Read FASTA file and store sequence data into an array
 */
int readFASTA(char *fn, int n, char *s) {
  int count = 0, ch;
  FILE *fp;

  if ((fp=fopen(fn, "r")) == NULL) {
    fprintf(stderr, "Unable to read from file '%s'\n", fn);
    return -1;
  }

  ch = fgetc(fp);
  if (ch != '>') {
    fprintf(stderr, "Invalid FASTA file format\n");
    return -2;
  }

  /* skip sequence header */
  do {
    ch = fgetc(fp);
  } while (ch != EOF && ch != '\n');

  /* sequence data start here */
  while (ch != EOF && count < n) {
    ch = fgetc(fp);
    if (ch == 'A' || ch == 'T' || ch == 'C' || ch == 'G' || ch == 'U' || ch == 'N' ||
        ch == 'a' || ch == 't' || ch == 'c' || ch == 'g' || ch == 'u' || ch == 'n') {
      ch = toupper(ch);
      if (ch == 'T')
        ch = 'U';
      s[count++] = ch;
    }
  }

  fclose(fp);

  if (count == 0)
    fprintf(stderr, "Sequence is of zero length\n");

  return count;
}

struct ProgArgs * setArgs(int argc, char *argv[]) {
  struct ProgArgs *args;
  int i, itmp;

  args = (struct ProgArgs *) malloc(sizeof(struct ProgArgs));
  if (args == NULL) {
    fprintf(stderr,"Failed to allocate memory for program arguments\n");
    return NULL;
  }

  /* Initialize structure elements */
  args->format = DEF_FORMAT;
  args->strfile = NULL;
  args->seqfile = NULL;
  args->pardir = NULL;

  /* Do the argument matching here... */
  if (argc < 2) {
    return NULL;
  }

  for (i=1; i<argc; i++)
    if (strcmp(argv[i], "-h") == 0)
      return NULL;

  i = 1;
  while (i < argc) {
    if (argv[i][0] == '-') {
      /* this is an option field */
      if (i >= argc-1) {
        fprintf(stderr,"Argument to '%s' is missing\n", argv[i]);
        return NULL;
      }

      if (strcmp(argv[i]+1,"f") == 0) {
        itmp = atoi(argv[++i]);
        if (itmp < 1 || itmp > 3) {
          fprintf(stderr,"Unknown structure file format %d\n", itmp);
          return NULL;
        } else args->format = itmp;

      } else if (strcmp(argv[i]+1,"p") == 0) {
        /* this specifies the directory from which parameter files
         * are to be read
         */
        i++;
        if (!args->pardir)
          args->pardir = strdup(argv[i]);
        else
          fprintf(stderr," Warning: ignoring duplicate parameter directory '%s'\n", argv[i]);

      } else if (strcmp(argv[i]+1,"s") == 0) {
        if (!args->seqfile)
          args->seqfile = argv[++i];
        else
          fprintf(stderr, "Ignoring duplicate sequence file '%s'\n", argv[++i]);
      } else {
        fprintf(stderr,"Unknown argument '%s'\n", argv[i]);
        return NULL;
      }

    } else {
      /* this specifies an input structure file */
      if (!args->strfile)
        args->strfile = argv[i];
      else
        fprintf(stderr, "Ignoring duplicate structure file '%s'\n", argv[i]);
    }

    i++;
  }

  if (!args->strfile) {
    fprintf(stderr, "No structure file given.\n");
    return NULL;
  }

  if (strcasecmp(args->strfile, "STDIN") == 0 && args->format == 1) {
    fprintf(stderr, "Unable to read from standard input for GCG connect format.\n");
    fprintf(stderr, "Please provide a structure file name as input.\n");
    return NULL;
  }

  if (args->format != 1)
    if (!args->seqfile) {
      fprintf(stderr, "Sequence file required for this structure format.\n");
      return NULL;
    }

  if (!args->pardir) {
    args->pardir = strdup(DEF_PARDIR);
  }

  return args;
}

void freeArgs(struct ProgArgs *args) {
  if (args) {
    if (args->pardir)
      free(args->pardir);

    free(args);
  }
}

void usage(char *pn) {
  printf("Usage: %s [options]... <structure file | STDIN>\n", pn);
  printf("Options:\n");
  printf("  -f <1, 2 or 3>      Specify the structure file format [default=%d]\n", DEF_FORMAT);
  printf("                        1 = GCG connect format\n");
  printf("                        2 = Base pair format\n");
  printf("                        3 = Helix triplet format\n");
  printf("  -h                  Display this information\n");
  printf("  -p <string>         Name of directory from which parameter files are read\n");
  printf("                      [default=%s]\n", DEF_PARDIR);
  printf("  -s <string>         FASTA sequence file name (required for bp & helix formats)\n");
  printf("\nNote: The STDIN option is only available for the base pair and helix triplet formats\n");
  printf("\n");
  return;
}
