#!/usr/bin/perl

#
# Get MAC addresses for all pgmp cluster machines
#

$nclust = 73;

$outtext = "char *MAC_ADDR[] = {";

for ($i=1; $i<=$nclust; $i++) {
  # pgmp1 (10.63.28.101) at 0:7:e9:23:dc:48
  $ret = `arp pgmp$i`;

  if ($ret =~ /at ([^\s\n]+)/) {
    $outtext .= "\n" if ($i % 3 == 1);
    $outtext .= " \"$1\",";
  }

#  if ($ret =~ /at (\w+):(\w+):(\w+):(\w+):(\w+):(\w+)/) {
#    printf "%02s:%02s:%02s:%02s:%02s:%02s\n", $1, $2, $3, $4, $5, $6;
#  }

}

$outtext =~ s/,$//;
$outtext .= "\n};\n";

print $outtext;
