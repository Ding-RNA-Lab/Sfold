#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "param.h"

#define DEF_PARDIR          "../param/"
#define DUPLEXLEN           10

#ifdef _CRAY
#  include <fortran.h>
#  define intstabprof         INTSTABPROF
#else
#  if !defined(_AIX) && !defined(__hpux)
#    define intstabprof       intstabprof_
#  endif
#  define _fcd          char *
#  define _cptofcd(a,b) (a)
#  define _fcdlen(a)    strlen(a)
#endif

struct ProgArgs {
  char *senseSeq;
  char *antisenseSeq;
  char *pardir;
};


/* function prototype */
int checkDuplex(char *sense, char *antisense);
double intstabprof(int *sense, int *antisense, int *nsirna, 
  char *pardir, int *pardirlen, double *intdg);
struct ProgArgs *setArgs(int argc, char *argv[]);
void freeArgs(struct ProgArgs *args);
int seq2id(char *seq, int *id, int n);
void usage(char *pn);


/* Parse command line arguments in C and pass them to the fortran subroutine */
int main(int argc, char *argv[]) {
  struct ProgArgs *args;
  int nsirna;
  int *senseID, *antisenseID;
  double *intdg;
  int i;
  int pardirlen=0;

  if ((args = setArgs(argc, argv)) == NULL) {
    usage(argv[0]);
    return -1;
  }

  /* check to see if the specified parameter directory and
     the required parameter files exist */
  if (verify_parfiles(args->pardir) < 0)
    return -2;
  pardirlen = strlen(args->pardir);

  nsirna = checkDuplex(args->senseSeq, args->antisenseSeq);
  if (nsirna < 0)
    return -3;

  /* allocate space */
  senseID = (int *) malloc(sizeof(int) * nsirna);
  antisenseID = (int *) malloc(sizeof(int) * nsirna);
  if (senseID == NULL || antisenseID == NULL) {
    fprintf(stderr," Error: failed to allocate space for 1-d integer arrays\n");
    return -4;
  }
  intdg = (double *) malloc(sizeof(double) * (nsirna-2));
  if (intdg == NULL) {
    fprintf(stderr," Error: failed to allocate space for 1-d double array\n");
    return -4;
  }

  /* convert sequences to base IDs according to (A,C,G,U)=(1,2,3,4) */
  seq2id(args->antisenseSeq, antisenseID, nsirna);
  seq2id(args->senseSeq, senseID, nsirna);


  /* call the Fortran subroutine with these arrays */
  intstabprof(senseID, antisenseID, &nsirna, args->pardir, &pardirlen, intdg);

  printf("\n");
  printf("                                 Internal\n");
  printf("Antisense  Antisense   Sense     Stability\n");
  printf("Position   Sequence   Sequence  (kcal/mol)\n");
  printf("------------------------------------------\n");
  printf("                         %c\n", args->senseSeq[nsirna-1]);
  printf("                         %c\n", args->senseSeq[nsirna-2]);
  for (i=0; i<nsirna-2; i++) {
    printf("%5d    %7c    %6c    %9.1f\n", i+1, args->antisenseSeq[i],
      args->senseSeq[nsirna-i-3], intdg[i]);
  }
  printf("               %c\n", args->antisenseSeq[nsirna-2]);
  printf("               %c\n", args->antisenseSeq[nsirna-1]);
  printf("\n");

  free(intdg);
  free(senseID);
  free(antisenseID);
  freeArgs(args);

  return 0;
}

/*
 * Check if the input strands form a valid duplex
 */
int checkDuplex(char *sense, char *antisense) {
  int len1, len2;
  int i;

  len1 = strlen(sense);
  len2 = strlen(antisense);

  if (len1 != len2) {
    fprintf(stderr," Error: input strands do not have the same length\n");
    return -1;
  }

  if (len1 < DUPLEXLEN) {
    fprintf(stderr," Error: input strands are too short\n");
    return -2;
  }

  for (i=0; i<len1; i++) {
    sense[i] = toupper(sense[i]);
    antisense[i] = toupper(antisense[i]);
    if (sense[i] == 'T')
      sense[i] = 'U';
    if (antisense[i] == 'T')
      antisense[i] = 'U';

    if (sense[i] != 'A' && sense[i] != 'C' &&
        sense[i] != 'G' && sense[i] != 'U') {
      fprintf(stderr," Error: invalid base '%c'\n", sense[i]);
      return -3;
    }
    if (antisense[i] != 'A' && antisense[i] != 'C' &&
        antisense[i] != 'G' && antisense[i] != 'U') {
      fprintf(stderr," Error: invalid base '%c'\n", antisense[i]);
      return -4;
    }
  }

  /* check base pairing between strands. we allow W-C and wobble pairs here */
  for (i=0; i<len1-2; i++) {
    switch (sense[i]) {
      case 'A':
        if (antisense[len1-3-i] != 'U') {
          fprintf(stderr, " Error: invalid pairing for base %d of sense strand\n", i+1);
          return -5;
        }
        break;
      case 'C':
        if (antisense[len1-3-i] != 'G') {
          fprintf(stderr, " Error: invalid pairing for base %d of sense strand\n", i+1);
          return -6;
        }
        break;
      case 'G':
        if (antisense[len1-3-i] != 'C' && antisense[len1-3-i] != 'U') {
          fprintf(stderr, " Error: invalid pairing for base %d of sense strand\n", i+1);
          return -7;
        }
        break;
      case 'U':
        if (antisense[len1-3-i] != 'A' && antisense[len1-3-i] != 'G') {
          fprintf(stderr, " Error: invalid pairing for base %d of sense strand\n", i+1);
          return -8;
        }
        break;
      default:
        fprintf(stderr, " Error: internal error\n");
        return -9;
    }
  }

  return len1;
}


struct ProgArgs *setArgs(int argc, char *argv[]) {
  struct ProgArgs *args;
  int i;

  args = (struct ProgArgs *) malloc(sizeof(struct ProgArgs));
  if (args == NULL) {
    fprintf(stderr," Error: failed to allocate memory for program arguments\n");
    return NULL;
  }

  /* Initialize structure elements */
  args->senseSeq = NULL;
  args->antisenseSeq = NULL;
  args->pardir = NULL;

  /* Do the argument matching here... */
  if (argc < 2) {
    return NULL;
  }

  for (i=1; i<argc; i++)
    if (strcmp(argv[i], "-h") == 0)
      return NULL;

  i = 1;
  while (i < argc) {
    if (argv[i][0] == '-') {
      /* this is an option field */
      if (i >= argc-1) {
        fprintf(stderr," Error: argument to '%s' is missing\n", argv[i]);
        return NULL;
      }

      if (strcmp(argv[i]+1,"a") == 0) {
        if (!args->antisenseSeq)
          args->antisenseSeq = argv[++i];
        else
          fprintf(stderr, " Warning: ignoring duplicate antisense sequence '%s'\n", argv[++i]);

      } else if (strcmp(argv[i]+1,"p") == 0) {
        /* this specifies the directory from which parameter files
         * are to be read
         */
        i++;
        if (!args->pardir)
          args->pardir = strdup(argv[i]);
        else
          fprintf(stderr," Warning: ignoring duplicate parameter directory '%s'\n", argv[i]);

      } else if (strcmp(argv[i]+1,"s") == 0) {
        if (!args->senseSeq)
          args->senseSeq = argv[++i];
        else
          fprintf(stderr, " Warning: ignoring duplicate sense sequence '%s'\n", argv[++i]);

      } else {
        fprintf(stderr," Error: unknown argument '%s'\n", argv[i]);
        return NULL;
      }

    } else {
      fprintf(stderr," Error: unknown argument '%s'\n", argv[i]);
      return NULL;
    }

    i++;
  }

  if (!args->antisenseSeq) {
    fprintf(stderr, " Error: no antisense sequence given.\n");
    return NULL;
  }

  if (!args->senseSeq) {
    fprintf(stderr, " Error: no sense sequence given.\n");
    return NULL;
  }

  if (!args->pardir) {
    args->pardir = strdup(DEF_PARDIR);
  }

  return args;
}

void freeArgs(struct ProgArgs *args) {
  if (args) {
    if (args->pardir)
      free(args->pardir);

    free(args);
  }
}

/*
 * Convert input sequence to an array of base IDs based on
 * the the following scheme: (A,C,G,U)=(1,2,3,4)
 */
int seq2id(char *seq, int *id, int n) {
  int i;

  for (i=0; i<n; i++) {
    switch (seq[i]) {
      case 'A':
        id[i] = 1;
        break;
      case 'C':
        id[i] = 2;
        break;
      case 'G':
        id[i] = 3;
        break;
      case 'U':
        id[i] = 4;
        break;
      default:
        fprintf(stderr, " Error: internal error\n");
        return -1;
    }
  }

  return n;
}

void usage(char *pn) {
  printf("Usage: %s -a <string> -s <string> [-p <string>]\n", pn);
  printf("Options:\n");
  printf("  -a <string>         Antisense strand of siRNA (5' -> 3', including the 2-nt\n");
  printf("                      3' overhang)\n");
  printf("  -h                  Display this information\n");
  printf("  -p <string>         Name of directory from which parameter files are read\n");
  printf("                      [default=%s]\n", DEF_PARDIR);
  printf("  -s <string>         Sense strand of siRNA (5' -> 3', including the 2-nt\n");
  printf("                      3' overhang)\n");
  printf("\n");
  return;
}
