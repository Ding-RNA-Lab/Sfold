/* 
 * This source file contains functions related to Sfold
 * execution permission.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "limithosts.h"
#include "sysinfo.h"


double mac2double(char *macaddr) {
  int num[6];
  int i;
  double sum = 0.0;

  for (i=0; i<6; i++)
    num[i] = -1;

  sscanf(macaddr, "%x:%x:%x:%x:%x:%x", 
    &num[0], &num[1], &num[2], &num[3], &num[4], &num[5]);

  for (i=0; i<6; i++) {
    if (num[i] < 0 || num[i] > 255)
      return -1;
    sum += num[i] * pow(16, (5-i)*2);
  }

  return sum;
}

// jds08:  What the shit is this shit?
// Talk about stupid nonsense.  This function verifies that the local MAC address is in a list of "allowed" addresses.
// I can't believe a scientist would limit his code this way, but behold, here's the evidence of it.
int verify_MAC(void) {

#if LIMITHOSTS != NOLIMIT
  char *tmpstr;
  FILE *pptr;
  char cmd[256], buf[256];
  int naddr, i, found = 0;
  double host_mac, tmp_mac;
  int num[6];

  /* if no limit, stop the verification function and return to main */
  if (!MAC_ADDR)
    return 0;

  naddr = sizeof(MAC_ADDR) / sizeof(char *);
  if (naddr == 0)
    return 0;

  #if OSTYPE == LINUX
    sprintf(cmd, "/sbin/ifconfig | grep HWaddr | awk '{print $5}'");
  #else
//    sprintf(cmd, "/usr/sbin/arp `uname -n` | awk '{print $4}'");
    sprintf(cmd, "/sbin/arp `uname -n` | awk '{print $4}'");
  #endif

  if ((pptr = popen(cmd, "r")) != NULL) {
    tmpstr = fgets(buf, 256, pptr);
    pclose(pptr);
  } else {
    tmpstr = NULL;
  }

  if (tmpstr != NULL) {
    host_mac = mac2double(tmpstr);
    if (host_mac < 0) {
      fprintf(stderr,"Error: unable to locate MAC address on this machine\n");
      return -1;
    }
  } else {
    fprintf(stderr,"Error: unable to locate MAC address on this machine\n");
    return -1;
  }

  for (i=0; i<naddr; i++) {
    tmp_mac = mac2double(MAC_ADDR[i]);
    if (tmp_mac == host_mac) {
      found = 1;
      break;
    }
  }

  if (found == 0) {
    fprintf(stderr,"This program cannot be run on this machine\n");
    return -2;
  }
#endif

  return 0;
}
