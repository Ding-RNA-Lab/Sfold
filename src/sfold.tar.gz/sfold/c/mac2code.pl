#!/usr/bin/perl

# convert lines of MAC addresses to array elements in C codes

$count = 0;
$str = "";

while (<>) {
  if ($count % 3 == 0) {
    $str .= "\n";
  }
  s/^\s+//;
  s/\s+$//;

  $str .= " \"$_\",";
  $count++;
}

$str =~ s/,$//;

print $str, "\n";
