/* 
 * This source file contains functions related to Sfold
 * core parameter files.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#define PARAM_H
#include "param.h"


int verify_parfiles(char *pardir) {
  int nfiles, i, dirlen, fnlen, maxlen=0, pathlen;
  char *ptr;

  /* First, check to see if the specified parameter directory exists */
  if (access(pardir, F_OK) != 0) {
    /* it does not exist! */
    fprintf(stderr," Error: unable to locate parameter directory!\n");
    return -2;
  }
  dirlen = strlen(pardir);

  nfiles = sizeof(PARFILES) / sizeof(char *);
  /* determine length of the longest filename */
  for (i=0; i<nfiles; i++) {
    fnlen = strlen(PARFILES[i]);
    if (fnlen > maxlen)
      maxlen = fnlen;
  }

  /* allocate enough memory for the longest path to file */
  /* +2 becuz +1 for '\n' and +1 for the char '/' */
  pathlen = dirlen + maxlen + 2;
  ptr = (char *) malloc(sizeof(char) * pathlen);
  if (ptr == NULL) {
    fprintf(stderr," Error: failed to allocate memory in verify_parfiles()\n");
    return -1;
  }

  for (i=0; i<nfiles; i++) {
    strcpy(ptr, pardir);
    strcat(ptr, "/");
    strcat(ptr, PARFILES[i]);

    /* Now check to see if this parameter file exists */
    if (access(ptr, F_OK) != 0) {
      /* it does not exist! */
      fprintf(stderr," Error: unable to locate parameter file '%s'!\n", ptr);
      return -3;
    }
  }
  free(ptr);

  return 0;
}
