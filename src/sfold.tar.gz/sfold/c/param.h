/*
 * This file contains a list of parameter files required
 * by the Sfold core program.
 */

#ifdef PARAM_H
char *PARFILES[] = { "stack.dat",
                     "dangle.dat",
                     "loop.dat",
                     "tstackh.dat",
                     "tstacki.dat",
                     "int11.dat",
                     "int21.dat",
                     "int22.dat",
                     "tloop.dat",
                     "triloop981.dat" };
#endif

/* Function prototypes from param.c */
extern int verify_parfiles(char *pardir);
