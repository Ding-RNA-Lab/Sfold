#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "readseq.h"


/*
 * A wrapper function for fopen to determine where we should read from.
 * If STDIN is the source of input, we can call fdopen instead of fopen
 */
FILE *file_open(char *p, char *m) {
  FILE *fp;

  if (strcasecmp(p, "STDIN") == 0) {
    /* we are reading from the standard input (0) */
    fp = fdopen(0, m);
  } else {
    /* do a normal file open */
    fp = fopen(p, m);
  }

  return fp;
}


/*
 * Parse plain sequence file and find the sequence length
 */
int getPlainlen(char *fn) {
  int count = 0, ch;
  FILE *fp;

  if ((fp=fopen(fn, "r")) == NULL) {
    fprintf(stderr, " Error: unable to read from file '%s'\n", fn);
    return -1;
  }

  /* sequence data start here */
  do {
    ch = fgetc(fp);
    if (ch == 'A' || ch == 'T' || ch == 'C' || ch == 'G' || ch == 'U' || ch == 'N' ||
        ch == 'a' || ch == 't' || ch == 'c' || ch == 'g' || ch == 'u' || ch == 'n')
      count++;
  } while (ch != EOF);

  fclose(fp);

  if (count == 0)
    fprintf(stderr, " Error: sequence is of zero length\n");

  return count;
}


/*
 * Parse the GCG connect file and find the sequence length
 */
int getCTlen(char *fn) {
  int count = 0, i, j;
  FILE *fp;
  char buf[256];
  char *ch, *tok;
  char nuc;

  if ((fp=file_open(fn, "r")) == NULL) {
    fprintf(stderr, " Error: unable to read from file '%s'\n", fn);
    return -1;
  }

  /* sequence data start here */
  do {
    i = j = 0;
    nuc = ' ';

    ch = fgets(buf, 256, fp);
    /* 1st column: position i */
    tok = strtok(ch, " ");
    if (tok != NULL)
      i = atoi(tok);
    /* 2nd column: Sequence alphabet */
    tok = strtok(NULL, " ");
    if (tok != NULL)
      nuc = tok[0];
    /* Skip column 3 and 4 */
    tok = strtok(NULL, " ");
    tok = strtok(NULL, " ");
    /* 5th column: position j */
    tok = strtok(NULL, " ");
    if (tok != NULL)
      j = atoi(tok);

    if ( i>0 && j>=0 && i!=j &&
         (nuc=='A' || nuc=='T' || nuc=='C' || nuc=='G' || nuc=='U' || nuc=='N' ||
          nuc=='a' || nuc=='t' || nuc=='c' || nuc=='g' || nuc=='u' || nuc=='n') ) {
      count++;
    }
  } while (ch != NULL);

  fclose(fp);

  if (count == 0)
    fprintf(stderr, " Error: sequence is of zero length\n");

  return count;
}

/*
 * Parse the input sequence file (in FASTA format) to find the sequence length
 */
int getFASTAlen(char *fn) {
  int count = 0, ch;
  FILE *fp;

  if ((fp=fopen(fn, "r")) == NULL) {
    fprintf(stderr, " Error: unable to read from file '%s'\n", fn);
    return -1;
  }

  ch = fgetc(fp);
  if (ch != '>') {
    fprintf(stderr, " Error: invalid FASTA file format\n");
    return -2;
  }

  /* skip sequence header */
  do {
    ch = fgetc(fp);
  } while (ch != EOF && ch != '\n');

  /* sequence data start here */
  while (ch != EOF) {
    ch = fgetc(fp);
    if (ch == 'A' || ch == 'T' || ch == 'C' || ch == 'G' || ch == 'U' || ch == 'N' ||
        ch == 'a' || ch == 't' || ch == 'c' || ch == 'g' || ch == 'u' || ch == 'n')
      count++;
  }

  fclose(fp);

  if (count == 0)
    fprintf(stderr, " Error: sequence is of zero length\n");

  return count;
}

/*
 * Read FASTA file and store sequence data into an array
 */
int readFASTA(char *fn, int n, char *s) {
  int count = 0, ch;
  FILE *fp;

  if ((fp=fopen(fn, "r")) == NULL) {
    fprintf(stderr, " Error: unable to read from file '%s'\n", fn);
    return -1;
  }

  ch = fgetc(fp);
  if (ch != '>') {
    fprintf(stderr, " Error: invalid FASTA file format\n");
    return -2;
  }

  /* skip sequence header */
  do {
    ch = fgetc(fp);
  } while (ch != EOF && ch != '\n');

  /* sequence data start here */
  while (ch != EOF && count < n) {
    ch = fgetc(fp);
    if (ch == 'A' || ch == 'T' || ch == 'C' || ch == 'G' || ch == 'U' || ch == 'N' ||
        ch == 'a' || ch == 't' || ch == 'c' || ch == 'g' || ch == 'u' || ch == 'n') {
      ch = toupper(ch);
      if (ch == 'T')
        ch = 'U';
      s[count++] = ch;
    }
  }

  fclose(fp);

  if (count == 0)
    fprintf(stderr, " Error: sequence is of zero length\n");

  return count;
}
