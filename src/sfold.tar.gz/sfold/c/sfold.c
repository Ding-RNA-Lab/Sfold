#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include "version.h"
#include "param.h"
#include "readseq.h"

#define DEF_WW              4
#define DEF_NR              1
#define DEF_W		    20
#define DEF_WI              21
#define DEF_COMPLEMENT      'F'
#define DEF_FORMAT          1
#define DEF_U0              1.928
#define DEF_ISEED           0
#define DEF_NSAMPLE         1000
#define DEF_PARDIR          "../param/"
#define DEF_OUTDIR          "../output/"
#define DEF_VERBOSE         0
#define DEF_EXT_MODS        0

#define MAX_NSAMPLE         1000000

#ifdef _CRAY
#  include <fortran.h>
#  define f77sub      F77SUB
#else
#  if !defined(_AIX) && !defined(__hpux)
#    define f77sub    f77sub_
#  endif
#  define _fcd          char *
#  define _cptofcd(a,b) (a)
#  define _fcdlen(a)    strlen(a)
#endif

struct ProgArgs {
	char *infile, *confile;
	char *pardir, *outdir;
	int nr, ww, w, wi;
	int noligo, nsirna;
	char complement;
	int seqformat;
	double u0;
	int lflen, iseed, nsample;
	int verbose; //Feature added by Adam 2009-02-19
	int ext_mods; //Feature added by Adam 2009-08-10
};

/* function prototype */
void f77sub(int *n, int *nr, int *ww, int *w, int *noligo, int *wi, int *nsirna,
		char *complement, int *numseq, int *single, int *hm, int *lm, int *fbp,
		int *sbase, int *ir6, int *ltype, int *h5, int *h3, int *hnum,
		int *seq1, int *ss, int *sseq, int *lcount, int *fbp10, double *pscale,
		double *probmbr, double *probmbl, double *probm1, double *probm2,
		double *probmm, double *psbase, double *lsumpr, double *x1, double *x2,
		double *x4, double *psseq, double *loopr, char *seq, char *seqc,
		char *seqcopy, char *infname, int *inflen, double *u0, int *lflen,
		int *iseed, int *nsample, double *fe, double *Bprob, char *confname,
		int *conflen, char *pardir, int *pardirlen, char *outdir,
		int *outdirlen, int *verbose, int *ext_mods);
int getseqlen(struct ProgArgs *args);
void usage(char *pn);
struct ProgArgs * setArgs(int argc, char *argv[]);
void freeArgs(struct ProgArgs *args);
extern int verify_MAC(void);
int verify_conformat(char *fn, int seqlen);

/* Take command line arguments from C and pass them to the fortran subroutine */
int main(int argc, char *argv[]) {
	struct ProgArgs *args;
	int n, i;
	int *numseq, *single, *hm, *lm, *fbp, *sbase, *ir6, *ltype, *h5, *h3, *hnum;
	int *seq1, *ss, *sseq, *lcount, *fbp10;
	double *pscale, *probmbr, *probmbl, *probm1, *probm2, *probmm, *psbase,
			*lsumpr;
	double *x1, *x2, *x4, *psseq, *loopr, *fe, *Bprob;
	char *seq, *seqc, *seqcopy;
	int inflen, conflen = 0, outdirlen = 0, pardirlen = 0;

	printf("\n%s, Version %s-%s\n", PROGRAM_TITLE, VERSION, COMPILE_DATE);
	printf("  <Partition function and statistical sampling module>\n\n");
	fflush(stdout);

	if (verify_MAC() < 0)
		return -5;

	if ((args = setArgs(argc, argv)) == NULL) {
		usage(argv[0]);
		return -1;
	}

	inflen = strlen(args->infile);
	n = getseqlen(args);
	if (n <= 0)
		return -3;

	if (args->confile != NULL) {
		if (verify_conformat(args->confile, n) <= 0)
			return -4;

		conflen = strlen(args->confile);
	}

	/* Check whether the local folding length is specified.
	 * if it's not specified by user or if it's set to a value
	 * longer than the sequence length-1, we set it to no limit,
	 * i.e. n-1
	 */
	if (args->lflen > n - 1 || args->lflen == 0)
		args->lflen = n - 1;

	/* Some more n-related error checkings */
	//  if (args->w > n) {
	//    fprintf(stderr," Error: Length of antisense oligos cannot be greater than the sequence length!\n");
	//    return -1;
	//  }
	//  if (args->wi > n) {
	//    fprintf(stderr," Error: Length of siRNA cannot be greater than the sequence length!\n");
	//    return -1;
	//  }
	args->noligo = n - args->w + 1;
	args->nsirna = n - args->wi + 1;

	/* Now check to see if the specified parameter directory and
	 the required parameter files exist */
	if (verify_parfiles(args->pardir) < 0)
		return -6;

	//  if (access(args->pardir, F_OK) != 0) {
	/* it does not exist! */
	//    fprintf(stderr," Error: unable to locate parameter directory!\n");
	//    return -6;
	//  }

	pardirlen = strlen(args->pardir);

	/* Now check to see if the specified output directory exists */
	if (access(args->outdir, F_OK) != 0) {
		/* it does not exist, create it! */
		if (mkdir(args->outdir, S_IRWXU | S_IRGRP | S_IXGRP | S_IROTH | S_IXOTH)
				!= 0) {
			/* failed to create output directory */
			fprintf(stderr, " Error: unable to create output directory!\n");
			return -7;
		}
		fprintf(stderr, " Output directory '%s' created\n", args->outdir);
	}
	outdirlen = strlen(args->outdir);

	/* allocate space */
	numseq = (int *) calloc(((size_t) n), sizeof(int));
	single = (int *) calloc(((size_t) n), sizeof(int));
	hm = (int *) calloc(((size_t) n), sizeof(int));
	lm = (int *) calloc(((size_t) n), sizeof(int));
	fbp = (int *) calloc(((size_t) n), sizeof(int));
	sbase = (int *) calloc(((size_t) n), sizeof(int));
	ir6 = (int *) calloc(((size_t) args->nr), sizeof(int));
	ltype = (int *) calloc(((size_t) n), sizeof(int));
	h5 = (int *) calloc(((size_t) n), sizeof(int));
	h3 = (int *) calloc(((size_t) n), sizeof(int));
	hnum = (int *) calloc(((size_t) n), sizeof(int));
	if (numseq == NULL || single == NULL || hm == NULL || lm == NULL || fbp
			== NULL || sbase == NULL || ir6 == NULL || ltype == NULL || h5
			== NULL || h3 == NULL || hnum == NULL) {
		fprintf(stderr,
				" Error: failed to allocate space for 1-d integer arrays\n");
		return -2;
	}

	seq1 = (int *) calloc(((size_t) 2 * n), sizeof(int));
	ss = (int *) calloc(((size_t) 3 * n), sizeof(int));
	sseq = (int *) calloc(((size_t) n * args->ww), sizeof(int));
	lcount = (int *) calloc(((size_t) 5 * n), sizeof(int));
	fbp10 = (int *) calloc(((size_t) 10 * n), sizeof(int));
	if (seq1 == NULL || ss == NULL || sseq == NULL || lcount == NULL || fbp10
			== NULL) {
		fprintf(stderr,
				" Error: failed to allocate space for 2-d integer arrays\n");
		return -2;
	}

	pscale = (double *) calloc(((size_t) n), sizeof(double));
	probmbr = (double *) calloc(((size_t) n), sizeof(double));
	probmbl = (double *) calloc(((size_t) n), sizeof(double));
	probm1 = (double *) calloc(((size_t) 3 * n), sizeof(double));
	probm2 = (double *) calloc(((size_t) n), sizeof(double));
	probmm = (double *) calloc(((size_t) 3 * n), sizeof(double));
	psbase = (double *) calloc(((size_t) n), sizeof(double));
	lsumpr = (double *) calloc(((size_t) n), sizeof(double));
	fe = (double *) calloc(((size_t) args->nsample), sizeof(double));
	Bprob = (double *) calloc(((size_t) args->nsample), sizeof(double));
	if (pscale == NULL || probmbr == NULL || probmbl == NULL || probm1 == NULL
			|| probm2 == NULL || probmm == NULL || psbase == NULL || lsumpr
			== NULL || fe == NULL || Bprob == NULL) {
		fprintf(stderr,
				" Error: failed to allocate space for 1-d double arrays\n");
		return -2;
	}

	x1 = (double *) calloc(((size_t)(n + 1) * (n + 1)), sizeof(double));
	x2 = (double *) calloc(((size_t)(n + 1) * (n + 1)), sizeof(double));
	x4 = (double *) calloc(((size_t)(n + 3) * (n + 3)), sizeof(double));
	psseq = (double *) calloc(((size_t) n * args->ww), sizeof(double));
	loopr = (double *) calloc(((size_t) 5 * n), sizeof(double));
	if (x1 == NULL || x2 == NULL || x4 == NULL || psseq == NULL || loopr
			== NULL) {
		fprintf(stderr,
				" Error: failed to allocate space for 2-d double arrays\n");
		return -2;
	}

	seq = (char *) calloc(((size_t) n), sizeof(char));
	seqc = (char *) calloc(((size_t) n), sizeof(char));
	seqcopy = (char *) calloc(((size_t) n), sizeof(char));
	if (seq == NULL || seqc == NULL || seqcopy == NULL) {
		fprintf(stderr,
				" Error: failed to allocate space for character arrays\n");
		return -2;
	}

	/*
	 * read in the sequence data before passing the array to Fortran. it's done
	 * in this way to save us some trouble under g77, as g77 does not support
	 * the way we used to read sequence data in fortran (one character at a time)
	 */
	readFASTA(args->infile, n, seq);
	for (i = 0; i < n; i++) {
		if (seq[i] == 'A')
			seqc[i] = 'T';
		else if (seq[i] == 'T' || seq[i] == 'U')
			seqc[i] = 'A';
		else if (seq[i] == 'C')
			seqc[i] = 'G';
		else if (seq[i] == 'G')
			seqc[i] = 'C';
		else if (seq[i] == 'N')
			seqc[i] = 'N';
	}

	/* call the Fortran subroutine with these arrays */
	f77sub(&n, &(args->nr), &(args->ww), &(args->w), &(args->noligo),
			&(args->wi), &(args->nsirna), &(args->complement), numseq, single,
			hm, lm, fbp, sbase, ir6, ltype, h5, h3, hnum, seq1, ss, sseq,
			lcount, fbp10, pscale, probmbr, probmbl, probm1, probm2, probmm,
			psbase, lsumpr, x1, x2, x4, psseq, loopr, seq, seqc, seqcopy,
			args->infile, &inflen, &(args->u0), &(args->lflen), &(args->iseed),
			&(args->nsample), fe, Bprob, args->confile, &conflen, args->pardir,
			&pardirlen, args->outdir, &outdirlen, &(args->verbose),
			&(args->ext_mods));

	freeArgs(args);

	return 0;
}

/*
 * Count the number of bases contained in a sequence file
 */
int getseqlen(struct ProgArgs *args) {
	int count = 0;

	switch (args->seqformat) {
	case 0:
		count = getPlainlen(args->infile);
		break;
	case 1:
		count = getFASTAlen(args->infile);
		break;
	case 2:
		break;
	default:
		fprintf(stderr, " Error: unknown sequence format\n");
		return -1;
	}

	return count;
}

void usage(char *pn) {
	printf("Usage: %s [options]... file\n", pn);
	printf("Options:\n");
	printf(
			"  -c <0 or 1>         Specify whether the input is a complement [default=0]\n");
	printf(
			"  -f <string>         Name of file containing folding constraints. Constraint\n");
	printf(
			"                      syntax follows what is used in mfold 3.1 [optional]\n");
	//  printf("  -x <0 or 1>         Specify the input sequence file format [default=%d]\n", DEF_FORMAT);
	//  printf("                      0 = Plain sequence file\n");
	//  printf("                      1 = File in FASTA format\n");
	printf("  -h                  Display this information\n");
	//  printf("  -i <integer>        Length of siRNA [default=%d]\n", DEF_WI);
	printf(
			"  -l <+ve integer>    Maximum distance between paired bases [default=no limit]\n");
	printf(
			"  -n <+ve integer>    Number of structures to be drawn in a sample [default=%d]\n",
			DEF_NSAMPLE);
	printf(
			"  -o <string>         Name of directory to which output files are written.\n");
	printf(
			"                      Directory will be created if it does not already exist.\n");
	printf(
			"                      Existing files will be overwritten. [default=%s]\n",
			DEF_OUTDIR);
	printf(
			"  -p <string>         Name of directory from which parameter files are read\n");
	printf("                      [default=%s]\n", DEF_PARDIR);
	printf(
			"  -r <+ve integer>    Seed for random number generator [default=system time]\n");
	printf("  -s <double>         Scaling factor [default=%g]\n", DEF_U0);
	printf("  -w <+ve integer>    Length of antisense oligos [default=%d]\n",
			DEF_W);
	printf(
			"  -e                  Do not truncate the large output file, sample.out\n");
	printf(
			"  -i <0,1,2,3>        1=do Sirna, 2=do Soligo, 3=both, 0=neither [default=0]\n");
	printf("\n");
	printf(
			"IMPORTANT: Use of this program is restricted to non-commercial internal\n");
	printf(
			"           research use only. Please read the enclosed license agreement\n");
	printf(
			"           before using this program. For more info, please visit us at:\n");
	printf("           http://sfold.wadsworth.org\n");
	printf("\n");
	return;
}

struct ProgArgs * setArgs(int argc, char *argv[]) {
	struct ProgArgs *args;
	int i, itmp;
	double dtmp;

	args = (struct ProgArgs *) malloc(sizeof(struct ProgArgs));
	if (args == NULL) {
		fprintf(stderr,
				" Error: failed to allocate memory for program arguments\n");
		return NULL;
	}

	/* Initialize structure elements */
	args->infile = NULL;
	args->nr = DEF_NR;
	args->ww = DEF_WW;
	args->w = DEF_W;
	args->wi = DEF_WI;
	args->complement = DEF_COMPLEMENT;
	args->seqformat = DEF_FORMAT;
	args->u0 = DEF_U0;
	args->lflen = 0;
	args->iseed = DEF_ISEED;
	args->nsample = DEF_NSAMPLE;
	args->confile = NULL;
	args->pardir = NULL;
	args->outdir = NULL;
	args->verbose = DEF_VERBOSE;
	args->ext_mods = DEF_EXT_MODS;

	/* Do the argument matching here... */
	if (argc < 2) {
		return NULL;
	}

	for (i = 1; i < argc; i++) {
		if (strcmp(argv[i], "-h") == 0)
			return NULL;
	}

	i = 1;
	while (i < argc) {
		if (argv[i][0] == '-') {
			/* this is an option field */
			if (i >= argc - 1) {
				if (argv[i][1] == 'e') {
					//exception for -e
				} else {
					fprintf(stderr, " Error: argument to '%s' is missing\n",
							argv[i]);
					return NULL;
				}
			}

			if (strcmp(argv[i] + 1, "e") == 0) {
				args->verbose = 1;
				fprintf(stderr, " Because of -e, sample.out will be preserved.\n");
			} else if (strcmp(argv[i] + 1, "w") == 0) {
				if ((itmp = atoi(argv[++i])) == 0) {
					fprintf(stderr, " Error: integer expected after '-w'\n");
					return NULL;
				} else
					args->w = itmp;
				//      } else if (strcmp(argv[i]+1,"i") == 0) {
				//        if ((itmp=atoi(argv[++i])) == 0) {
				//          fprintf(stderr," Error: integer expected after '-i'\n");
				//          return NULL;
				//        } else args->wi = itmp;
			} else if (strcmp(argv[i] + 1, "c") == 0) {
				if ((itmp = atoi(argv[++i])) == 1)
					args->complement = 'T';
				else
					fprintf(stderr, " Setting -c 0\n");
			} else if (strcmp(argv[i] + 1, "f") == 0) {
				/* this specifies a constraint file containing disallowed BPs */
				i++;
				if (!args->confile)
					args->confile = argv[i];
				else
					fprintf(
							stderr,
							" Warning: ignoring duplicate constraint file '%s'\n",
							argv[i]);

				/*
				 *      } else if (strcmp(argv[i]+1,"f") == 0) {
				 *        itmp = atoi(argv[++i]);
				 *        if (itmp < 0 || itmp > 1) {
				 *          fprintf(stderr," Error: unknown input file format %d\n", itmp);
				 *          return NULL;
				 *        } else args->seqformat = itmp;
				 */
			} else if (strcmp(argv[i] + 1, "s") == 0) {
				if ((dtmp = strtod(argv[++i], NULL)) == 0.0) {
					fprintf(stderr,
							" Error: double precision expected after '-s'\n");
					return NULL;
				} else
					args->u0 = dtmp;

			} else if (strcmp(argv[i] + 1, "l") == 0) {
				if ((itmp = atoi(argv[++i])) <= 0) {
					fprintf(stderr,
							" Error: positive integer expected after '-l'\n");
					return NULL;
				} else
					args->lflen = itmp;

			} else if (strcmp(argv[i] + 1, "n") == 0) {
				if ((itmp = atoi(argv[++i])) <= 0) {
					fprintf(stderr,
							" Error: positive integer expected after '-n'\n");
					return NULL;
				} else if (itmp > MAX_NSAMPLE) {
					fprintf(
							stderr,
							" Error: number of structures to be drawn is too large (max=%d)\n",
							MAX_NSAMPLE);
					return NULL;
				} else
					args->nsample = itmp;

			} else if (strcmp(argv[i] + 1, "o") == 0) {
				/* this specifies the directory for writing output files */
				i++;
				if (!args->outdir)
					args->outdir = strdup(argv[i]);
				else
					fprintf(
							stderr,
							" Warning: ignoring duplicate output directory '%s'\n",
							argv[i]);

			} else if (strcmp(argv[i] + 1, "p") == 0) {
				/* this specifies the directory from which parameter files
				 * are to be read
				 */
				i++;
				if (!args->pardir)
					args->pardir = strdup(argv[i]);
				else
					fprintf(
							stderr,
							" Warning: ignoring duplicate parameter directory '%s'\n",
							argv[i]);

			} else if (strcmp(argv[i] + 1, "r") == 0) {
				if ((itmp = atoi(argv[++i])) <= 0) {
					fprintf(stderr,
							" Error: positive integer expected after '-r'\n");
					return NULL;
				} else
					args->iseed = itmp;

			} else if (strcmp(argv[i] + 1, "i") == 0) {
				if ((itmp = atoi(argv[++i])) < 0 || itmp > 3) {
					fprintf(stderr,
							" Error: 0,1,2,or 3 expected after '-i'\n");
					return NULL;
				} else
					args->ext_mods = itmp;

			} else {
				fprintf(stderr, " Error: unknown argument '%s'\n", argv[i]);
				return NULL;
			}

		} else {
			/* this specifies an input file */
			if (!args->infile)
				args->infile = argv[i];
			else
				fprintf(stderr, " Warning: ignoring duplicate input file\n");
		}

		i++;
	}

	if (!args->infile) {
		fprintf(stderr, " Error: no input file\n");
		return NULL;
	}
	if (!args->outdir) {
		args->outdir = strdup(DEF_OUTDIR);
	}
	if (!args->pardir) {
		args->pardir = strdup(DEF_PARDIR);
	}

	return args;
}

void freeArgs(struct ProgArgs *args) {
	if (args) {
		if (args->outdir)
			free(args->outdir);
		if (args->pardir)
			free(args->pardir);

		free(args);
	}
}

/* This function parses and verifies the format of the
 * constraint file. The constraint file should follow
 * the syntax used in zuker's mfold 3.1, i.e. which
 * contains 4 columns in a single line:
 * {F/P} i j k
 * where F is to force pairing and P is to prevent
 * pairing.
 */
int verify_conformat(char *fn, int seqlen) {
	int count = 0, ch1, ch2, n1, n2, n3;
	char buf[1024], action;
	FILE *fp;

	if ((fp = fopen(fn, "r")) == NULL) {
		fprintf(stderr, " Error: unable to read from file '%s'\n", fn);
		return -1;
	}

	/* constraints start here */
	do {
		ch1 = fscanf(fp, "%[^\n]", buf);
		ch2 = fgetc(fp);

		if (ch1) {
			action = ' ';
			n1 = n2 = n3 = -1;
			sscanf(buf, "%c %d %d %d", &action, &n1, &n2, &n3);

			switch (action) {
			case 'F':
				/* forcing a particular pair to be formed (i * j) OR forcing
				 * a particular base not to be single-stranded (i * any);
				 * these are not supported yet as of 2004/12/28!
				 */
				fprintf(stderr,
						" Warning: forcing a BP to form is not yet supported in Sfold.\n");
				fprintf(stderr,
						"          Ignoring '%s' in constraint file.\n", buf);
				break;

			case 'P':
				/* preventing a particular pair to be formed (no i * j) OR
				 * forcing a particular base to be open (i * nothing);
				 */

				/* now do some error checking here */

				/* n2 can be 0 when we want to prevent not only a particular
				 * i and j, but to prevent base i in forming a pair with anyone
				 */
				if (n1 <= 0 || n2 < 0 || n3 <= 0 || n1 > seqlen || n2 > seqlen) {
					fprintf(stderr, " Error: out-of-range detected in '%s'\n",
							buf);
					return -2;
				}
				if (n2 > 0 && n2 - n1 < 4) {
					fprintf(stderr, " Error: j-i < 4 in '%s'\n", buf);
					return -2;
				}
				if (n1 + n3 - 1 > seqlen) {
					fprintf(stderr, " Error: out-of-range detected in '%s'\n",
							buf);
					return -2;
				}
				if (n2 > 0 && n2 - n3 + 1 <= 0) {
					fprintf(stderr, " Error: out-of-range detected in '%s'\n",
							buf);
					return -2;
				}
				if (n2 > 0 && n3 > (n2 - n1 + 1) / 2) {
					fprintf(stderr, " Error: out-of-range detected in '%s'\n",
							buf);
					return -2;
				}

				count++;
				break;

			default:
				if (strlen(buf) != 0) {
					fprintf(stderr, " Error: unknown format in '%s'\n", buf);
					return -2;
				}
				break;
			}

		}
	} while (ch1 != EOF && ch2 != EOF);

	fclose(fp);

	if (count == 0)
		fprintf(stderr,
				" Error: no valid base pair found in constraint file '%s'\n",
				fn);

	return count;
}
