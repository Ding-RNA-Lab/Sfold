/* This file is modified by the automatic script */
/* Please DO NOT edit manually */


#define UNKNOWN		0
#define LINUX		1
#define SUNOS		2
#define OSF1		4
#define DARWIN		8

#define OSTYPE		LINUX


/* Unknown already defined earlier */
/* #define UNKNOWN		0 */
#define I386		1
#define X86_64		2
#define SPARC		4
#define ALPHA		8
#define POWERPC		16

#define MACH		X86_64

