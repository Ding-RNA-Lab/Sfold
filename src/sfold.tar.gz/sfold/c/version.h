/* This file contains version number information */

#define PROGRAM_TITLE   "Sfold Executable Code for Academic Users"
#define VERSION         "2.2"
/*
 * No need to modify compilation date manually. This is automatically
 * modified by ../scripts/update.version.pl during compilation.
 */
#define COMPILE_DATE    "20110126"
