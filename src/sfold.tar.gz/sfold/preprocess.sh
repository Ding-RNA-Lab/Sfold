#!/bin/sh

ctrl_c() {
  echo "Compilation aborted by user."
}

# location variables
PP="$PWD/fortran_pp.pl"
DMA="$PWD/fortran_dma.pl"
FDIR="$PWD/f77"
CDIR="$PWD/c"


trap  ctrl_c   2

str=`date +%y%m%d.%H%M%S`

mv -f $FDIR/data.f $FDIR/data.$str.f
#mv -f $FDIR/discrete.f $FDIR/discrete.$str.f
mv -f $FDIR/energy.f $FDIR/energy.$str.f
mv -f $FDIR/main.f $FDIR/main.$str.f
mv -f $FDIR/mpnum.f $FDIR/mpnum.$str.f
mv -f $FDIR/partf.f $FDIR/partf.$str.f
mv -f $FDIR/pprob.f $FDIR/pprob.$str.f
mv -f $FDIR/sample.f $FDIR/sample.$str.f
mv -f $FDIR/sirna.f $FDIR/sirna.$str.f
#mv -f $FDIR/sirna_v0.f $FDIR/sirna_v0.$str.f
mv -f $FDIR/soligo.f $FDIR/soligo.$str.f

$PP $FDIR/data.$str.f > $FDIR/data.f
#$PP $FDIR/discrete.$str.f > $FDIR/discrete.f
$PP $FDIR/energy.$str.f > $FDIR/energy.f
$PP $FDIR/mpnum.$str.f > $FDIR/mpnum.f
$PP $FDIR/partf.$str.f > $FDIR/partf.f
$PP $FDIR/pprob.$str.f > $FDIR/pprob.f
$PP $FDIR/sample.$str.f > $FDIR/sample.f
$PP $FDIR/sirna.$str.f > $FDIR/sirna.f
$PP $FDIR/soligo.$str.f > $FDIR/soligo.f

# this line is for the dynamic memory allocation version
$PP $FDIR/main.$str.f | $DMA > $FDIR/main.f

# this line is for the static memory allocation version
#$PP $FDIR/main.$str.f > $FDIR/main.f


make -f makefile2 $@


mv -f $FDIR/data.$str.f $FDIR/data.f
#mv -f $FDIR/discrete.$str.f $FDIR/discrete.f
mv -f $FDIR/energy.$str.f $FDIR/energy.f
mv -f $FDIR/main.$str.f $FDIR/main.f
mv -f $FDIR/mpnum.$str.f $FDIR/mpnum.f
mv -f $FDIR/partf.$str.f $FDIR/partf.f
mv -f $FDIR/pprob.$str.f $FDIR/pprob.f
mv -f $FDIR/sample.$str.f $FDIR/sample.f
mv -f $FDIR/sirna.$str.f $FDIR/sirna.f
mv -f $FDIR/soligo.$str.f $FDIR/soligo.f
