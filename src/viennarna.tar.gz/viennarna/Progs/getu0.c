#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "fold.h"
#include "part_func.h"

extern int local_folding_length;

void usage(char *pn);
int getFASTAlen(char *fn);
int readFASTA(char *fn, char **str);
void* space(int s);

/*--------------------------------------------------------------------------*/

int main(int argc, char *argv[])
{
  char *string;
  char *structure=NULL;
  int   i, length;
  double min_en;
  double sfact=1.07;
  double kT = (37+273.15)*1.98717/1000;
  double scale;

  if (argc != 2 && argc != 3)
    usage(argv[0]);

  if ((length=readFASTA(argv[1], &string)) <= 0)
    return -1;

  if (argc == 3) {
    // local folding length is specified
    local_folding_length = atoi(argv[2]);
    if (local_folding_length <= 0 || local_folding_length > length-1) {
      fprintf(stderr, "Error: invalid local folding length '%s'\n", argv[2]);
      return -1;
    }
  }

  for (i=0; i<length; i++) {
    string[i] = toupper(string[i]);
    if (string[i] == 'T')
      string[i] = 'U';
  }
  structure = (char *) space((unsigned) length+1);

  initialize_fold(length);
  min_en = fold(string, structure);
  scale = exp(-(sfact*min_en) /kT/length);

//  printf("length = %d\n", length);
//  printf("minimum free energy = %6.2f kcal/mol\n", min_en);
//  printf("scaling factor = %g\n", scale);
  printf("%g\n", scale);

  (void) fflush(stdout);

  return 0;
}

void usage(char *pn)
{
  printf(" Usage: %s <sequence file in FASTA format> {optional local folding length}\n", pn);

  exit(-1);
}

int getFASTAlen(char *fn) {
  int count = 0, ch;
  FILE *fp;

  if ((fp=fopen(fn, "r")) == NULL) {
    fprintf(stderr, "Unable to read from file '%s'\n", fn);
    return -1;
  }

  ch = fgetc(fp);
  if (ch != '>') {
    fprintf(stderr, "Invalid FASTA file format\n");
    return -2;
  }

  /* skip sequence header */
  do {
    ch = fgetc(fp);
  } while (ch != EOF && ch != '\n');

  /* sequence data start here */
  while (ch != EOF) {
    ch = fgetc(fp);
    if (ch == 'A' || ch == 'T' || ch == 'C' || ch == 'G' || ch == 'U' ||
        ch == 'a' || ch == 't' || ch == 'c' || ch == 'g' || ch == 'u')
      count++;
  }

  fclose(fp);

  if (count == 0)
    fprintf(stderr, "Sequence is of zero length\n");

  return count;
}


int readFASTA(char *fn, char **str) {
  int count = 0, ch, len;
  FILE *fp;

  len = getFASTAlen(fn);

  if ((fp=fopen(fn, "r")) == NULL) {
    fprintf(stderr, "Unable to read from file '%s'\n", fn);
    return -1;
  }

  ch = fgetc(fp);
  if (ch != '>') {
    fprintf(stderr, "Invalid FASTA file format\n");
    return -2;
  }

  /* skip sequence header */
  do {
    ch = fgetc(fp);
  } while (ch != EOF && ch != '\n');

  *str = (char *) space((unsigned) len+1);

  /* sequence data start here */
  while (ch != EOF && count < len) {
    ch = fgetc(fp);
    if (ch == 'A' || ch == 'T' || ch == 'C' || ch == 'G' || ch == 'U' ||
        ch == 'a' || ch == 't' || ch == 'c' || ch == 'g' || ch == 'u')
      (*str)[count++] = ch;
  }

  (*str)[count] = '\0';

  fclose(fp);

  if (count == 0) {
    fprintf(stderr, "Sequence is of zero length\n");
    free(*str);
    return 0;
  }

  return len;
}

