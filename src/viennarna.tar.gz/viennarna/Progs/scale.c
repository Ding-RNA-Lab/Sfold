#include <stdio.h>
#include <math.h>

int main(void) {
  double min_en = -206.3;
  int length = 589;
  double sfact = 1.07;
  double kT = (37+273.15)*1.98717/1000;
  double scale;

  scale = exp(-(sfact*min_en) /kT/length);
  printf("scaling factor = %g\n", scale);
}
